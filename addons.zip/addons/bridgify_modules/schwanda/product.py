# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _

###########
##  schwanda=# alter table product_product add x_template_code character varying;
##  add column x_template_code in Odoo
###########
class Template(models.Model):
    _inherit = "product.template"

    template_code = fields.Char('PK', size=64)
