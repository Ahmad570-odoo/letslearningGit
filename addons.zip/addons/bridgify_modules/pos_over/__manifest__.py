
# -*- coding: utf-8 -*-

{
    'name': 'Estonian Print: Sales Overview',
    'version': '0.1',
    'author': "NDAP",
    'website': 'http://bridgify.at',
    'category': 'Point of Sale',
    'description': """
Estonian print
==============
""",
    'depends': ['bridgify','pos_sales_overview'],
    'data': [
        'views/templates.xml',
    ],
    'qweb': [
    ],
    'installable': True,
    'auto_install': False,
}
