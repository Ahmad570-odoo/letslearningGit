# -*- coding: utf-8 -*-
{
    "name": 'web_action_conditionable',
    "version": "10.0.1.0.0",
    "depends": [
        'base',
        'web',
    ],
    'data': ['views/view.xml'],
    "author": "Cristian Salamea,Odoo Community Association (OCA)",
    "license": "AGPL-3",
    'installable': True,
}
