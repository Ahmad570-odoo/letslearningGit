# -*- coding: utf-8 -*-
# (C) 2017 Vadim (<http://based.at>).
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import models
