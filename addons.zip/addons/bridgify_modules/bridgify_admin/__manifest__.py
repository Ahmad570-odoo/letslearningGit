{
    'name': 'PoS: Bridgify Admin',
    'version': '0.2',
    'author': "Vadim, bridgify GmbH",
    'website': "http://bridgify.at",
    'license': "OPL-1",
    'category': 'Point of Sale',
    'description': """
    """,
    'depends': ['base_vat', 'bridgify'],
    'data': [
        'security/client_admin.xml',
        'views/res_partner.xml',
        'views/templates.xml',
        'data/cron.xml',
    ],
    'installable': True,
    'auto_install': False,
}
