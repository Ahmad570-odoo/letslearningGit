# -*- coding: utf-8 -*-

import uuid
import psycopg2
from datetime import datetime
from contextlib import closing
from urlparse import urlparse, urlunparse

import odoo.tools
from odoo import api, fields, models, modules, SUPERUSER_ID, _
from odoo.exceptions import AccessDenied, AccessError, ValidationError
from odoo.addons.base.res.res_partner import WARNING_MESSAGE, WARNING_HELP

# Let databases starting with 'tmpl_' be our templates
db = odoo.sql_db.db_connect('postgres')
with closing(db.cursor()) as cr:
    cr.execute("SELECT datname, description FROM pg_shdescription JOIN pg_database ON objoid = pg_database.oid"
               "  WHERE datname like 'tmpl_%'")
    DB_TEMPLATES = [(r['datname'], r['description']) for r in cr.dictfetchall()]


class ResPartner(models.Model):
    _inherit = 'res.partner'

    email = fields.Char(index=True)

    client = fields.Boolean('Is a Client', compute='_is_client', store=True, index=True)
    template = fields.Selection(DB_TEMPLATES, 'Template')
    restaurant = fields.Boolean('Is a restaurant?')
    db_name = fields.Char('Name', readonly=True, help='Clients database name')
    db_href = fields.Char('Link', compute='_db_href', help='Link to the database instance')
    db_name_computed = fields.Char('Name', help='Proposed clients database name', store=True,
                                   compute='_compute_db_name', inverse='_set_db_name',
                                   groups='bridgify.group_client_admin')
    db_create_date = fields.Datetime('Created', readonly=True)
    start_date = fields.Datetime('Started', help='Subscription start date')
    end_date = fields.Datetime('Expires', help='Subscription expiration date')

    _sql_constraints = [('email_uniq', 'unique (email)', "This email address already exists!")]

    def get_config(self):
        base_url = self.env['ir.config_parameter'].get_param('bridgify.base_url')
        admin_db = self.env['ir.config_parameter'].get_param('bridgify.admin_db')
        if not base_url or not admin_db:
            config = odoo.addons.bridgify.config
            base_url = base_url or config['base_url']
            admin_db = admin_db or config['admin_db']
        return base_url, admin_db

    @api.depends('db_name', 'start_date', 'end_date')
    def _is_client(self):
        for partner in self:
            partner.client = partner.db_name and partner.start_date and \
                             (partner.end_date < fields.Date.today() if partner.end_date else True)

    def _db_href(self):
        for partner in self:
            if partner.db_name:
                base_url, admin_db = self.get_config()
                partner.db_href = base_url.replace(admin_db, partner.db_name)
            else:
                partner.db_href = False

    @api.depends('name')
    def _compute_db_name(self):
        db = odoo.sql_db.db_connect('postgres')
        for partner in self:
            if partner.db_name or not partner.is_company or partner.parent_id:
                partner.db_name_computed = False
            else:
                with closing(db.cursor()) as cr:
                    def check(name, count=0):
                        db_name = name.strip() if count == 0 else name.strip() + '-' + str(count)
                        cr.execute("SELECT datname FROM pg_database WHERE datname = %s", (db_name,))
                        if cr.fetchone():
                            count += 1
                            return check(name, count)
                        return db_name

                    db_name = check(partner.name.replace(' ', '-').lower()[:8])
                    partner.db_name_computed = db_name

    def _set_db_name(self):
        for partner in self:
            db_name_computed = partner.db_name_computed or ''
            self._cr.execute("UPDATE res_partner SET db_name_computed=%s WHERE id=%s",
                             (db_name_computed, partner.id))

    def _install_addons(self, env, partner):
        addons = ['bridgify', 'pos_mobile', 'pos_discount', 'pos_variants', 'pos_sales_overview']
        if partner.country_id.code == 'AT':
            addons += ['l10n_at', 'pos_digital_signature', 'pos_sign_atrust']
        if partner.country_id.code == 'DE':
            addons += ['l10n_de_skr03']
        if partner.restaurant:
            addons += ['bridgify_gastro', 'pos_mobile_restaurant', 'pos_printer_network']
        for addon in env['ir.module.module'].search([('name', 'in', list(addons))]):
            addon.button_immediate_install()

    def _create_db(self, db_name, lang, country_code=None, template=None):
        # Template database to copy, specify with parameter --db_template when starting odoo instance
        template = template or odoo.tools.config['db_template']
        create = template == 'template1'
        try:
            if create:
                odoo.service.db.exp_create_database(db_name, False, lang,
                                                    user_password='DooOconnect88!', login='bh@bridgify.eu',
                                                    country_code=country_code)
            else:
                odoo.service.db._drop_conn(self.env.cr, template)
                odoo.service.db.exp_duplicate_database(template, db_name)
        except psycopg2.Error, e:
            raise AccessError(_('Error %s database "%s". Details can be found below: \n\n %s')
                              % (create and 'creating' or 'copying', db_name, e.pgerror,))
        return True

    def _create_company(self, env, partner):
        # Access groups for POS manager
        groups = [('point_of_sale', 'group_pos_manager'),
                  ('stock', 'group_stock_user'),
                  ('product', 'group_uom'),
                  ('account', 'group_account_invoice'),
                  ('base', 'group_partner_manager'),
                  ('base', 'group_user')]

        data = partner.read(('name', 'website', 'street', 'zip', 'city', 'mobile',
                             'vat', 'email', 'lang', 'fax', 'street2', 'phone', 'tz'))[0]
        data.update(country_id=partner.country_id.id)
        main_partner = env['ir.model.data'].xmlid_to_object('base.main_partner')
        res = main_partner.write(data)

        # Create user
        group_ids = [env['ir.model.data'].get_object_reference(*group)[1] for group in groups]
        env['res.users'].create({
            'login': data['email'],
            'name': data['name'],
            'email': data['email'],
            'company_id': 1,
            'company_ids': [(4, 1, 0)],
            'groups_id': [(4, group_id, 0) for group_id in group_ids]
        })
        return res

    def _update_pos_config(self, env, partner):
        # Reset "Main" PoS
        main = env['ir.model.data'].xmlid_to_object('point_of_sale.pos_config_main')
        name = 'Kassa' if partner.country_id.code == 'AT' else 'Kasse'
        journal_ids = env['account.journal'].search([('journal_user', '=', True), ('type', 'in', ['bank', 'cash'])])
        main.write({
            'name': name,
            'journal_ids': [(4, journal.id, 0) for journal in journal_ids],
            'uuid': str(uuid.uuid4())
        })
        main.sequence_id.write({'prefix': "%s/" % name})

    def _update_account_config(self, env, partner):
        default_sale_tax = None
        if partner.country_id.code == 'AT':
            tax_ids = [tax.res_id for tax in env['ir.model.data'].search([('model', '=', 'account.tax'),
                                                                          '|', ('name', 'like', 'tax_at_mwst_20'),
                                                                               ('name', 'like', 'tax_at_mwst_10')])]
            env['account.tax'].browse(tax_ids).write({'price_include': True, 'include_base_amount': True})
            default_sale_tax = env['account.tax'].browse(tax_ids).filtered(lambda r: r.name.endswith('20%'))
        if partner.country_id.code == 'DE':
            tax_ids = [tax.res_id for tax in env['ir.model.data'].search([('model', '=', 'account.tax'),
                                                                          '|', ('name', 'like', 'tax_ust_19_skr03'),
                                                                               ('name', 'like', 'tax_ust_7_skr03')])]
            env['account.tax'].browse(tax_ids).write({'price_include': True, 'include_base_amount': True})
            default_sale_tax = env['account.tax'].browse(tax_ids).filtered(lambda r: r.name.startswith('19%'))
        if default_sale_tax:
            default_sale_tax_id = default_sale_tax.id
            company_id = env['ir.model.data'].xmlid_to_object('base.main_partner').id
            env['ir.values'].set_default('account.config.settings', 'default_sale_tax_id', default_sale_tax_id)
            env['ir.values'].set_default('product.template', 'taxes_id', [default_sale_tax_id], company_id=company_id)

    @api.multi
    def create_db(self):
        if not self.user_has_groups('bridgify.group_client_admin'):
            raise AccessDenied()
        self.ensure_one()
        db_name = self.db_name_computed
        if not db_name or db_name.lower() in ('false', 'none', 'undefined'):
            raise ValidationError(_('Database name required'))

        # Check if db already exists
        self._cr.execute("SELECT datname FROM pg_database WHERE datname = %s", (db_name,))
        if self._cr.fetchone():
            raise ValidationError(_('Database "%s" already exists') % db_name)

        # Validate VAT and email - required to create new database instance
        if not self.vat or not self.email or not self.country_id:
            raise ValidationError(_('%s is required to create an instance. Partner "%s"')
                                  % ('UID number' if not self.vat else 'Email address' if not self.email else 'Country', self.name,))

        if self._create_db(db_name, self.lang, self.country_id.code, self.template):
            registry = modules.registry.Registry.new(db_name)
            with api.Environment.manage(), registry.cursor() as cr:
                env = api.Environment(cr, SUPERUSER_ID, {})

                # Change base URL
                base_url, admin_db = self.get_config()
                env['ir.config_parameter'].set_param('bridgify.base_url', base_url)
                env['ir.config_parameter'].set_param('bridgify.admin_db', admin_db)
                base_url = base_url.replace(admin_db, db_name)
                env['ir.config_parameter'].set_param('web.base.url', base_url)

                self._install_addons(env, self)

            #
            # Reload registry and perform additional tasks
            #
            registry = modules.registry.Registry.new(db_name, update_module=True)
            with api.Environment.manage(), registry.cursor() as cr:
                env = api.Environment(cr, SUPERUSER_ID, {})
                # update main partner:
                self._create_company(env, self)
                # update main POS
                self._update_pos_config(env, self)
                # update accounting configuration:
                self._update_account_config(env, self)

            self.write({'db_name': db_name, 'db_create_date': datetime.now()})
            self._cr.commit()

    @api.model
    def force_update_all(self, module_name=None):
        module_name = module_name or 'bridgify'
        for partner in self.search([('db_name', '!=', False)]):
            registry = modules.registry.Registry.new(partner.db_name)
            with api.Environment.manage(), registry.cursor() as cr:
                env = api.Environment(cr, SUPERUSER_ID, {})
                for module in env['ir.module.module'].search([('name', '=', module_name)]):
                    module.button_immediate_upgrade()
