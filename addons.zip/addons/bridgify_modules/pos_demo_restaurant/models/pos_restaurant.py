# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class RestaurantFloor(models.Model):

    _inherit = 'restaurant.floor'

    pos_config_id = fields.Many2one(ondelete='cascade')
    table_ids = fields.One2many(copy=True)


class RestaurantTable(models.Model):

    _inherit = 'restaurant.table'

    floor_id = fields.Many2one(ondelete='cascade')
