# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api


class PosConfig(models.Model):
    _inherit = 'pos.config'

    floor_ids = fields.One2many('restaurant.floor', 'pos_config_id', string='Floor plans',
                                help='The list of floor plans for the PoS')
