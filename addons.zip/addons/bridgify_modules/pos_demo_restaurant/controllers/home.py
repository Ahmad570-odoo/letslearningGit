# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import _
from odoo.http import request
import odoo.addons.pos_demo.controllers.home as home


class Home(home.Home):

    def get_labels(self, **d):
        res = super(Home, self).get_labels(**d)
        res['labels'].update({'h2': _('Check out our restaurant solution')})
        return res

    def save_session(self, tz, sid, unsuccessful_message=''):
        res = super(Home, self).save_session(tz, sid, unsuccessful_message=unsuccessful_message)
        if res and 'new_pos' in res:
            # Copy floor plans
            [floor.copy({'pos_config_id': res['new_pos']}) for floor in request.env.user.pos_config.floor_ids]
        return res
