{
    'name': 'PoS Demo - Restaurant',
    'version': '0.2',
    'author': "Vadim, bridgify GmbH",
    'website': "http://bridgify.at",
    'license': "OPL-1",
    'category': 'Point of Sale',
    'description': """
PoS Demo - Restaurant
=====================
Creates temporary PoS terminal per web session.
    """,
    'depends': ['pos_restaurant', 'pos_demo'],
    'installable': True,
    'auto_install': False,
}
