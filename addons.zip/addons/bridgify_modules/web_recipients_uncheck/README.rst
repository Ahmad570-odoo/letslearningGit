Description
-----------
Uncheck additional recipients and followers when
sending a message at the customer view.