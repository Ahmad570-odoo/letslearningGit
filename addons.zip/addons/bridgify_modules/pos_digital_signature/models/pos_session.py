# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api


class PosSession(models.Model):
    _inherit = 'pos.session'

    @api.multi
    def action_pos_session_open(self):
        self.env['pos.certificate'].check_certificate()
        return super(PosSession, self).action_pos_session_open()

    def _report_add_where_hook(self):
        # Exclude RKSV technical receipts
        return "(pos_order.status is NULL OR pos_order.status='' OR pos_order.status NOT IN %s) AND " % str(self.env['pos.order'].get_technical_states())

    def _report_filter_hook(self):
        # Exclude RKSV technical receipts ORM style
        return lambda r: r.status not in self.env['pos.order'].get_technical_states()
