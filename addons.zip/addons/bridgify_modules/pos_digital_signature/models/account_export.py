# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api


class AccountExport(models.TransientModel):
    _inherit = 'bridgify.account.export'

    def _report_add_where_hook(self):
        # Exclude RKSV technical receipts
        return " AND (status is NULL OR status='' OR status NOT IN %s) " % \
               str(self.env['pos.order'].get_technical_states())

    file_type = fields.Selection(selection_add=[('protocol', 'DEP')], default='protocol')
