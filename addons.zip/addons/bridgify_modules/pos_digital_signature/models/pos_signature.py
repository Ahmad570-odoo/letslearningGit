# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import models, _
from odoo.exceptions import UserError


class PosSignature(models.AbstractModel):
    _name = 'pos.signature'
    _description = 'PoS Signature Object'
    _not_implemented = _("PoS signature interface module is not installed!")

    def create_certificate(self):
        raise UserError(self._not_implemented)

    def create_user_cert(self, uid, email, classification_key_type):
        raise UserError(self._not_implemented)

    def get_certificate(self, user, password):
        raise UserError(self._not_implemented)

    def create_session(self, user, password):
        raise UserError(self._not_implemented)

    def sign(self, session_info, payload):
        raise UserError(self._not_implemented)
