# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import base64
import struct
import logging
from datetime import datetime
from odoo import fields, models, api

_logger = logging.getLogger()

try:
    from Crypto.Cipher import AES
    import Crypto.Util.Counter
    from Crypto.Hash import SHA256
except ImportError, e:
    _logger.error('Skipping digital signature module: %s', e)


class PosOrder(models.Model):
    _inherit = 'pos.order'

    @api.model
    def _order_fields(self, ui_order):
        res = super(PosOrder, self)._order_fields(ui_order)
        res.update({
            'note': ui_order['note'] or False,
            'status': ui_order['status'] or ('refund-receipt' if ui_order.get('refund') else False),
            # Trying to recover from a bug that left orders without certificate_id
            'certificate_id': ui_order['certificate_id'] if 'certificate_id' in ui_order
                                else self.env['pos.certificate'].check_certificate().id,
            'sales_counter': ui_order['sales_counter'],
            'jws_signature': ui_order['jws_signature'],
            'rksv_string': ui_order['rksv_string'],
        })
        return res

    @api.model
    def _process_order(self, ui_order):
        order = super(PosOrder, self)._process_order(ui_order)

        if not order.jws_signature \
                or (order.jws_signature [:20] == 'eyJhbGciOiJFUzI1NiJ9'
                    and order.jws_signature[-46:] == 'U2ljaGVyaGVpdHNlaW5yaWNodHVuZyBhdXNnZWZhbGxlbg'):
            payload = self.generate_order_payload(order)
            _logger.info(payload)

            order.jws_signature = self.sign_order(payload)
            order.rksv_string = payload

        order.config_id.sales_counter = order.sales_counter
        return order

    @api.multi
    def _get_qr_string(self):
        for order in self:
            try:
                signature = order.jws_signature.split(".")[2].replace('-', "+").replace('_', "/")
                signature += b'=' * ((4 - len(signature) % 4) % 4)
                order.qr_string = '_'.join((order.rksv_string, signature))
            except (AttributeError, IndexError):
                order.qr_string = False

    status = fields.Char('RKSV Type')
    certificate_id = fields.Many2one('pos.certificate', string='Certificate ID', default=None)
    sales_counter = fields.Integer('Turnover')
    jws_signature = fields.Char('JWS Signature')
    rksv_string = fields.Char('Payload String')
    qr_string = fields.Text('QR String', compute='_get_qr_string')

    @api.model
    def get_technical_states(self):
        return 'start-receipt', 'monthly-receipt', 'zero-receipt', 'training-receipt', 'end-receipt'

    @api.multi
    def action_pos_order_paid(self):
        """ Make RKSV technical orders "done"
        """
        if self.status in self.get_technical_states():
            self.write({'state': 'done'})
            return True
        return super(PosOrder, self).action_pos_order_paid()

    @api.model
    def sign_order(self, orderPayload):
        _logger.info(orderPayload)
        return self.env['pos.signature'].sign(self.env['pos.certificate'].get_session(), orderPayload)

    @api.model
    def generate_order_payload(self, order):
        certificate = self.env['pos.certificate'].check_certificate()
        betrag_satz_normal = 0
        betrag_satz_ermaessigt1 = 0
        betrag_satz_ermaessigt2 = 0
        betrag_satz_besonders = 0
        betrag_satz_null = 0
        order_total = 0

        # Taxes
        for line in order.lines:
            if len(line.tax_ids) > 0:
                if line.tax_ids[0].amount == 20:
                    betrag_satz_normal += line.price_subtotal_incl
                elif line.tax_ids[0].amount == 10:
                    betrag_satz_ermaessigt1 += line.price_subtotal_incl
                elif line.tax_ids[0].amount == 13:
                    betrag_satz_ermaessigt2 += line.price_subtotal_incl
                elif line.tax_ids[0].amount == 19:
                    betrag_satz_besonders += line.price_subtotal_incl
                else:
                    betrag_satz_null += line.price_subtotal_incl
            else:
                betrag_satz_null += line.price_subtotal_incl
            order_total += line.price_subtotal_incl

        if order.sales_counter:
            sales_counter = order.sales_counter
        else:
            sales_counter = order.config_id.sales_counter
            if order.status not in self.get_technical_states():
                sales_counter += order_total * 100

        sales_counter_aes256_icm = 'TRA' if order.status == 'training-receipt' \
            else 'STO' if order.status == 'refund-receipt' \
            else order.encrypt_sales_counter(sales_counter)

        # Find previous order signature
        previous_order = self.search([('config_id', '=', order.config_id.id), ('id', '<', order.id)],
                                     limit=1, order="id desc")

        if previous_order.jws_signature:
            jwspreviousorder = previous_order.jws_signature
        else:
            jwspreviousorder = str(order.config_id.id)
        hashObj = SHA256.new()
        hashObj.update(jwspreviousorder)
        previous_signature = base64.b64encode(hashObj.digest()[0:8])

        # Date/time: need to convert to local timezone
        date_order = fields.Datetime.context_timestamp(self, fields.Datetime.from_string(order.date_order))

        payload = "_R1-" + certificate[0].zdaid + "_"                           # ZDA id
        payload += str(order.config_id.id)                                      # PoS id
        payload += "_" + order.pos_reference.split(' ')[-1]                     # Receipt number
        payload += "_" + datetime.strftime(date_order, "%Y-%m-%dT%H:%M:%S")     # Date/time
        payload += "_" + ("%.2f" % betrag_satz_normal).replace(".", ",")        # Amount tax 20%
        payload += "_" + ("%.2f" % betrag_satz_ermaessigt1).replace(".", ",")   # Amount tax 10%
        payload += "_" + ("%.2f" % betrag_satz_ermaessigt2).replace(".", ",")   # Amount tax 13%
        payload += "_" + ("%.2f" % betrag_satz_null).replace(".", ",")          # Amount tax 0%
        payload += "_" + ("%.2f" % betrag_satz_besonders).replace(".", ",")     # Amount tax 19%
        payload += "_" + base64.b64encode(sales_counter_aes256_icm)             # Encrypted turnover counter
        payload += "_" + certificate.serial_hex.lower()                         # Certificate serial number
        payload += "_" + previous_signature                                     # Previous signature

        return payload

    @api.multi
    def encrypt_sales_counter(self, sales_counter):
        self.ensure_one()
        aes_key = base64.b64decode(self.config_id.aes_key)
        concat_id = str(self.config_id.id) + self.pos_reference.split(' ')[-1]
        hash_obj = SHA256.new()
        hash_obj.update(concat_id)
        iv = hash_obj.digest()[0:16].encode("hex")
        counter = Crypto.Util.Counter.new(128, initial_value=long(iv, base=16))
        encoded_value = struct.pack('>q', sales_counter)
        encrypted = AES.new(aes_key, AES.MODE_CTR, counter=counter).encrypt(encoded_value)
        return encrypted

    @api.multi
    def serialize(self):
        res = super(PosOrder, self).serialize()
        res.update({'qr_string': self.qr_string})
        return res
