# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _


class ResCompany(models.Model):
    _inherit = "res.company"

    display_qrcode = fields.Boolean('Display QR Code', help='Display QR code on PoS receipt?', default=True)

    @api.multi
    def onchange_display_qrcode(self, display_qrcode=True):
        result = {}
        if not display_qrcode:
            result.update({'warning': {
                'title': _('Warning!'),
                'message': _('Hiding QR code is violation of RKSV. \n'
                             'Make sure your yearly turnover does not exceed 7.500 Euro.'),
            }})
        return result
