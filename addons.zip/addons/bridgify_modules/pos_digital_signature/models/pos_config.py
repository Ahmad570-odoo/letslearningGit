# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import uuid
import json
import base64
import logging
import datetime
from odoo import fields, models, api, _
import urlparse
from urllib import urlencode
from odoo.exceptions import except_orm, Warning, RedirectWarning

_logger = logging.getLogger(__name__)


class PosConfig(models.Model):
    _inherit = 'pos.config'

    aes_key = fields.Char('AES Key', readonly=True, copy=False, default=lambda self: base64.b64encode(str(uuid.uuid4())[0:32]))
    sales_counter = fields.Integer('Sales Counter', readonly=True, default=0)
    sales_counter_euros = fields.Float(compute="_sales_counter_euros", string='Sales Counter', readonly=True)

    # _sql_constraints = [
    #     ('aes_key_uniq', 'unique (aes_key)', 'The AES key already exists under other kassa !')
    # ]

    @api.depends('sales_counter')
    @api.multi
    def _sales_counter_euros(self):
        for item in self:
            item.sales_counter_euros = float(item.sales_counter) / 100.0


    @api.multi
    def init_check(self):
        """ Check if PoS terminal has issued an init receipt
        """
        self.ensure_one()
        for order in self.env['pos.order'].search([('config_id', '=', self.id), ('status', '=', 'start-receipt'),
                                                   ('create_date', '>', '2017-03-21 00:00:00')]):
            return True
        return False

    @api.multi
    def monthly_check(self):
        """ Check if PoS terminal has issued a monthly receipt
        """
        self.ensure_one()
        month_start = (datetime.datetime.now().replace(day=1) - datetime.timedelta(days=1)).replace(day=10, hour=0, minute=0, second=0)
        month_end = datetime.datetime.now()

        for order in self.env['pos.order'].search([
            ('config_id', '=', self.id),
            # ('status', 'in', ('start-receipt', 'monthly-receipt', 'end-receipt')),
            ('status', '=', 'monthly-receipt'),
            ('create_date', '>=', month_start.strftime("%Y-%m-%d %H:%M:%S")),
            ('create_date', '<=', month_end.strftime("%Y-%m-%d %H:%M:%S"))
        ]):
            return True
        return False

    @api.model
    def action_monthly_closing(self):
        for config in self.search([]):
            for export in config.get_protocol():
                document = self.env['bridgify.account.export.save'].create({'start_date': export.start_date,
                                                                            'end_date': export.end_date,
                                                                            'pos_config_id': config.id,
                                                                            'file': export.file})
                # this part gets the link of the monthly receipt json
                # base_url = self.env['ir.config_parameter'].get_param('web.base.url')
                # query = {'db': self._cr.dbname}
                # fragment = {'action': 'bridgify_account_export.action_account_exports_form',
                #             'view_type': 'form',
                #             'model': 'bridgify.account.export.save',
                #             'id': document.id,
                #             }
                #
                # json_url = urlparse.urljoin(base_url, "?%s#%s" % (urlencode(query), urlencode(fragment)))
                # send mail
                template_id = 'pos_digital_signature.pos_config_protocol_template'
                template = self.env.ref(template_id, False)
                if template:
                    template.email_to = export.company_mail
                    template.send_mail(config.id, force_send=True)
                else:
                    _logger.warning("No email template found for sending protocol: %s" % template_id)

            if not config.monthly_check():
                # TODO: Generate monthly receipt
                pass

    @api.multi
    @api.returns('bridgify.account.export')
    def get_protocol(self):
        self.ensure_one()

        # check last two months for monthly receipts
        two_months_start = (datetime.datetime.now().replace(day=1) - datetime.timedelta(days=40)).replace(day=1, hour=0, minute=0, second=0)
        two_months_end = datetime.datetime.now()

        start_date = None
        end_date = None
        for order in self.env['pos.order'].search([('create_date', '>=', fields.Datetime.to_string(two_months_start)),
                                                   ('create_date', '<=', fields.Datetime.to_string(two_months_end)),
                                                   ('config_id', '=', self.id),
                                                   ('status', '=', 'monthly-receipt')],
                                                   # ('status', 'in', ('monthly-receipt', 'start-receipt', 'end-receipt'))],
                                                  order='create_date desc', limit=2):

            if not end_date:
                end_date = order.create_date
            elif not start_date:
                start_date = order.create_date

        # if there are no monthly receipts, take the "normal" start and end date of month
        if not start_date or not end_date:
            start_date = (datetime.datetime.now().replace(day=1) - datetime.timedelta(days=1)).replace(day=1, hour=0, minute=0, second=0)
            end_date = (datetime.datetime.now().replace(day=1) - datetime.timedelta(days=1)).replace(hour=23, minute=59, second=59)

        export = self.env['bridgify.account.export'].create({'start_date': start_date, 'end_date': end_date,
                                                            'file_type': 'protocol', 'pos_config_id': self.id})
        export.button_create_csv()
        return export
