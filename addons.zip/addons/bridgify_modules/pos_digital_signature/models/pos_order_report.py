# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, tools


class PosOrderReport(models.Model):
    _inherit = "report.pos.order"

    def _report_add_where_hook(self):
        # Exclude RKSV technical receipts
        return "(s.status is NULL OR s.status='' OR s.status NOT IN %s) " % \
               str(self.env['pos.order'].get_technical_states())
