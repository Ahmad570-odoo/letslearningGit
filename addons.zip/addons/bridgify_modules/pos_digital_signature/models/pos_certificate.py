# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import json
import datetime
import logging

from odoo import fields, models, api, _
from odoo.exceptions import UserError

_logger = logging.getLogger()


class PosCertificate(models.Model):
    _name = 'pos.certificate'
    _order = 'id desc'

    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self._context.get('force_company', self.env.user.company_id.id))
    signature = fields.Text('Signature Certificate')
    authorities = fields.Text('Certification Authorities')
    serial = fields.Char('Serial Number')
    serial_hex = fields.Char('Serial Number HEX')
    alg = fields.Char('Certificate Algorithm')
    user = fields.Char('RKSV User')
    password = fields.Char('RKSV Password')
    session_id = fields.Char('Session ID')
    session_key = fields.Char('Session Key')
    session_expiration = fields.Datetime('Opening Date')
    zdaid = fields.Char('ZDA ID')

    @api.model
    @api.returns('self')
    def check_certificate(self):
        certificate = self.sudo().with_context({'force_company': self.env.user.company_id.id}).search([])
        if not certificate:
            ## check whether ATU number is set
            company = self.env.user.company_id
            if not company.email:
                raise UserError(_("The cash register needs a certificate to fullfil the legal requirements of Austrian RKSV 2017. Please enter your VAT OR tax-payer identification number AND your email address to acquire one."))

            if company.partner_id.vat:
                user_cert = self.env['pos.signature'].create_user_cert(company.partner_id.vat, company.email, 0)
            elif company.tax_number:
                user_cert = self.env['pos.signature'].create_user_cert(company.tax_number, company.email, 2)
            else:
                raise UserError(_("The cash register needs a certificate to fullfil the legal requirements of Austrian RKSV 2017. Please enter your VAT OR tax-payer identification number AND your email address to acquire one."))

            ## create user certificate and save to DB
            _logger.info("Creating certificate")
            _logger.info(user_cert)
            data = {
                "signature": user_cert['signature'],
                "authorities": json.dumps(user_cert['authorities']),
                "serial": user_cert['serial'],
                "serial_hex": user_cert['serial_hex'],
                "alg": user_cert['alg'],
                "user": user_cert['user'],
                "password": user_cert['password'],
                "zdaid": user_cert['zdaid']
            }
            _logger.info(data)
            certificate = self.create(data)
            if company.email:
                #if E-Mail fails still go on
                try:
                    self.action_send_certificate(certificate)
                except:
                    pass
        return max(certificate)

    @api.model
    def get_session(self):
        certificate = self.check_certificate()

        if certificate.session_expiration and datetime.datetime.strptime(certificate.session_expiration,'%Y-%m-%d %H:%M:%S') >= datetime.datetime.now():
            _logger.info("Returning stored session")
            return {"sessionid": certificate.session_id, "sessionkey": certificate.session_key}
        
        _logger.info("Creating new session")
        
        certificate = self.check_certificate()
        sessionInfo = self.env['pos.signature'].create_session(certificate.user, certificate.password)
        certificate.session_id = sessionInfo['sessionid']
        certificate.session_key = sessionInfo['sessionkey']
        certificate.session_expiration = datetime.datetime.now() + datetime.timedelta(hours=1)
        
        return sessionInfo

    @api.model
    def action_send_certificate(self, certificate):
        template = self.env.ref('pos_digital_signature.pos_certificate_template', False)
        if template:
            template.send_mail(certificate.id, force_send=True)
        else:
            _logger.info("Failed to send certificate: no template defined")
        return True
