/* Copyright 2017 bridgify GmbH: See LICENSE file for full copyright and licensing details.
 */

odoo.define('pos_digital_signature.signature', function (require){
"use strict"

    var framework = require('web.framework');
    var chrome = require('point_of_sale.chrome');
    var models = require('point_of_sale.models');
    var screens = require('point_of_sale.screens');
    var gui = require('point_of_sale.gui');

    var Model = require('web.DataModel');

    var core = require('web.core');
    var _t = core._t;

    var rksv_receipt_types = {
        RKSV_START_RECEIPT : 'START',
        RKSV_TRAINING_RECEIPT : 'TRA',
        RKSV_STORNO_RECEIPT : 'STO',
        RKSV_ZERO_RECEIPT : 'ZERO'
    };

    var RKSVButton = screens.ActionButtonWidget.extend({
        template: 'RKSVButton',
        button_click: function(){
            var rksv_screen = this.gui.screen_instances['rksv'];
            rksv_screen.set_mode('closable');
            this.gui.show_screen('rksv');
        }
    });

    screens.define_action_button({
        'name': 'overview',
        'widget': RKSVButton,
        'condition': function(){
            return (this.pos.user.role === 'manager');
        },
    });

    var RKSVScreenWidget = screens.ScreenWidget.extend({

        template:'RKSVScreen',

        init: function(parent,options) {

            this._super(parent,options);
            this.pos_session_id = this.pos.pos_session.id;
            this.pos_config_id = this.pos.config.id;
            this.mode = 'closable';

        },
        show: function() {
            this._super();

            var self = this;
            this.renderElement();

            this.$('.back').click(function(){
                self.gui.show_saved_screen(self.pos.get_order());
            });
            this.$('.print_start').click(function(){
                self.print_receipt(
                    rksv_receipt_types.RKSV_START_RECEIPT,
                    "start-receipt",
                    _t("This is a start receipt for register: ") + self.pos.config.name + ". " +
                    _t("Please find a user manual in your inbox. Further information is available on our website: http://bridgify.at")
                );
            });
            this.$('.print_stop').click(function(){
                self.print_receipt(
                    rksv_receipt_types.RKSV_ZERO_RECEIPT,
                    "end-receipt",
                    _t("This is a closing receipt for register: ") + self.pos.config.name
                );
            });
            this.$('.print_monthly').click(function(){
                self.print_receipt(
                    rksv_receipt_types.RKSV_ZERO_RECEIPT,
                    "monthly-receipt",
                    _t("This is a monthly receipt for register: ") + self.pos.config.name
                );
            });
            this.$('.print_zero').click(function(){
                self.print_receipt(
                    rksv_receipt_types.RKSV_ZERO_RECEIPT,
                    "zero-receipt",
                    _t("This is a null receipt for register: ") + self.pos.config.name
                );
            });
            this.$('.print_training').click(function(){
                self.print_receipt(
                    rksv_receipt_types.RKSV_TRAINING_RECEIPT,
                    "training-receipt",
                    _t("This is a training receipt for register: ") + self.pos.config.name
                );
            });

            if(this.mode == "unclosable" || this.mode == "init") {
                self.$('.back').hide();
            }
            else if(this.mode == "closable") {
                self.$('.back').show();
            }
            if (this.mode == "init"){
                $('#monthly, #overview, .print_stop, .print_monthly, .print_zero, .print_training').hide();
                $('#title').html(_t('Welcome to bridgify.connect'));
            } else if (this.mode == "monthly"){
                $('#start, #overview, .print_start, .print_stop, .print_zero, .print_training').hide();
                $('#title').html(_t('Warning!'));
            } else {
                $('#start, #monthly').hide();
                var cashier = this.pos.get_cashier();
                if (cashier['role'] == 'manager') {
                    $('.print_start, .print_stop').show();
                } else {
                    $('.print_start, .print_stop').hide();
                }
            }

        },
        set_mode: function(mode) {
            var self = this;
            this.mode = mode;
        },
        print_receipt: function(type, status, note) {
            var self = this;
            var existing_order = this.pos.get_order();
            var order = this.pos.dummy_order();
            order.note = note;
            order.status = status;
            order.sign(type).always(function() {
                self.trigger('change', self);
                self.gui.show_screen('receipt');
                self.pos.push_order(order).always(function () {
                    if (existing_order !== undefined) {
                        self.gui.current_screen.print()
                        if (self.pos.get_order() !== undefined) {
                            self.pos.delete_current_order();
                        }
                        self.pos.set('selectedOrder', existing_order);
                        self.gui.back();
                    }
                });
            });
        }
    });

    gui.define_screen({name:'rksv', widget: RKSVScreenWidget});

    models.load_fields('res.company', ['display_qrcode']);

    models.load_models([
        {
                model:  'pos.certificate',
                order:  [],
                fields: [],
                domain: [],
                loaded: function(self, data){
                    self.certificates = data;
                }
        }, {
                model:  'pos.order',
                fields: ['jws_signature'],
                order:  ['-id'],
                domain: function(self){ return [['session_id.config_id','=', self.config.id]]; },
                limit : 1,
                loaded: function(self, data){
                    if (data.length) {
                        self.previous_jws_signature = data[0].jws_signature;
                    }
                }
        }
    ]);

    var _super_pos = models.PosModel.prototype;
    models.PosModel = models.PosModel.extend({
        get_certificate: function() {
            return this.certificates.length && this.certificates[0]
        },
        /*
        * Upload pending orders
        * */
        upload_and_reload: function() {

            var local_orders = this.db.get_orders();

            if (!local_orders.length) {
                return;
            }
            var self = this;
            framework.blockUI();
            var localorder_intervalrun = 0;
            var localorder_interval = window.setInterval(function() {
                localorder_intervalrun += 1;
                if (self.db.get_orders().length >= 1) {
                    self.push_order();
                } else {
                    window.location.reload();
                }

                if (localorder_intervalrun == 10) {
                    clearInterval(localorder_interval);
                }
            },1000);
        },
        after_load_server_data: function() {
            this.upload_and_reload();
            return _super_pos.after_load_server_data.call(this);
        },
        /**
         * Create dummy init order
         */
        dummy_order: function(){
            var order = new models.Order({},{pos:this});
            this.get('orders').add(order);
            this.set('selectedOrder', order);
            return order;
        }
    });

    var _super_order = models.Order.prototype;
    models.Order = models.Order.extend({
        initialize: function(attr, options) {
            _super_order.initialize.apply(this, arguments);
            this.note = this.note || "";
            this.status = this.status || "";
            this.certificate_id = this.certificate_id || this.pos.certificate_id;
            this.jws_signature = this.jws_signature || "";
            this.rksv_string = this.rksv_string || "";
            this.sales_counter = this.sales_counter || 0;
            if (options.rksv_string) {
                this.rksv_string = options.rksv_string;
            }
            if (options.jws_signature) {
                var signature = options.jws_signature.split(".")[2].replace(/\-/g,"+").replace(/_/g, "/");
                var equalCounter = ((4 - signature.length % 4) % 4);
                for (var i = 0; i < equalCounter; i++) {
                    signature += "=";
                }
                this.setSignature(signature);
            }
        },
        export_as_JSON: function() {
            var json = _super_order.export_as_JSON.apply(this, arguments);
            json.note = this.note;
            json.status = this.status;
            json.certificate_id = this.certificate_id;
            json.sales_counter = this.sales_counter;
            json.jws_signature = this.jws_signature;
            json.rksv_string = this.rksv_string;
            json.qr_string = this.qr_string;
            return json;
        },
        set_jws_signature: function(jws_signature) {
            this.jws_signature = jws_signature;
            this.trigger('change', this);
        },
        get_jws_signature: function() {
            return this.jws_signature;
        },
        clone: function() {
            return _super_order.clone.apply(this, arguments);
        },
        init_from_JSON: function(json) {
            _super_order.init_from_JSON.apply(this, arguments);
            this.note = json.note;
            this.status = json.status;
            this.certificate_id = json.certificate_id;
            this.sales_counter = json.sales_counter;
            this.jws_signature = json.jws_signature;
            this.rksv_string = json.rksv_string;
            this.qr_string = json.qr_string;
        },
        sign: function(receiptType) {
            var self = this;
            var posOrderModel = new Model('pos.order');
            var payload = self.getRKSVString(receiptType);
            framework.blockUI();
            return posOrderModel.call('sign_order',[payload], undefined, {timeout : 10000}).then(function (jws_signature) {
                self.jws_signature = jws_signature;
                var signature = jws_signature.split(".")[2].replace(/\-/g,"+").replace(/_/g, "/");
                var equalCounter = ((4 - signature.length % 4) % 4);
                for (var i = 0; i < equalCounter; i++) {
                    signature += "=";
                }
                self.setSignature(signature);
                return true;
            }).fail(function (){
                // Dummy signature
                var header = "eyJhbGciOiJFUzI1NiJ9";
                self.setSignature("U2ljaGVyaGVpdHNlaW5yaWNodHVuZyBhdXNnZWZhbGxlbg");
                self.jws_signature = header + "." + base64.encode(payload) + "." + self.signature;
                console.error('Failed to sign orders:', self.pos.get_order());
            }).always(function() {
                framework.unblockUI();
                self.pos.previous_jws_signature = self.jws_signature;
            });
        },

        encryptSalesCounter : function() {
            var concatenatedIdentifier = this.pos.config.id + this.uid;
            var aesKeybase64 = this.pos.config.aes_key;
            var currentSalesCounter = this.sales_counter;

            var hashed = SHA256(concatenatedIdentifier, {outFormat : 'hex'});
            var iv = hashed.substr(0,32); // first 16 bytes = 32 chars in hex

            // AES kex
            var aesKey = base64.decode(aesKeybase64);
            var aesKeyBytes = new Array(aesKey.length);
            for (var i = 0; i < aesKey.length; i++) {
                aesKeyBytes[i] = aesKey.charCodeAt(i);
            }

            // Turnover counter
            var textBytes = new Uint8Array([
                 (currentSalesCounter & 0xff00000000000000) >> 56,
                 (currentSalesCounter & 0x00ff000000000000) >> 48,
                 (currentSalesCounter & 0x0000ff0000000000) >> 40,
                 (currentSalesCounter & 0x000000ff00000000) >> 32,
                 (currentSalesCounter & 0x00000000ff000000) >> 24,
                 (currentSalesCounter & 0x0000000000ff0000) >> 16,
                 (currentSalesCounter & 0x000000000000ff00) >> 8,
                 (currentSalesCounter & 0x00000000000000ff)
            ]);
            var aesCtr = new aesjs.ModeOfOperation.ctr(aesKeyBytes, aesjs.util.convertStringToBytes(iv, "hex"));
            var encryptedBytes = aesCtr.encrypt(textBytes);
            var encryptedString = "";
            for (var i = 0; i < encryptedBytes.length; i++) {
                encryptedString += String.fromCharCode(encryptedBytes[i]);
            }
            return encryptedString;
        },
        getRKSVString: function(receiptType) {
            // Skip if already generated
            if (this.rksv_string) {
                return this.rksv_string;
            }
            var payload;
            var self = this;
            var certificate = this.pos.get_certificate();
            this.certificate_id = certificate.id;

            var taxes = this.get_tax_details(),
                betrag_satz_normal = 0,
                betrag_satz_ermaessigt1 = 0,
                betrag_satz_ermaessigt2 = 0,
                betrag_satz_besonders = 0,
                betrag_satz_null = 0;

            // Taxes
            taxes.forEach(function (item) {
                if (item.tax.amount == 20) {
                    betrag_satz_normal = self.get_total_for_taxes(item.tax.id);
                } else if (item.tax.amount == 10) {
                    betrag_satz_ermaessigt1 = self.get_total_for_taxes(item.tax.id);
                } else if (item.tax.amount == 13) {
                    betrag_satz_ermaessigt2 = self.get_total_for_taxes(item.tax.id);
                } else if (item.tax.amount == 19) {
                    betrag_satz_besonders = self.get_total_for_taxes(item.tax.id);
                } else {
                    betrag_satz_null = self.get_total_for_taxes(item.tax.id);
                }
            });

            var sales_counter_aes256_icm;
            this.sales_counter = this.pos.config.sales_counter;
            if (this.refund || receiptType == rksv_receipt_types.RKSV_STORNO_RECEIPT) {
                this.sales_counter += this.get_total_with_tax() * 100;
                sales_counter_aes256_icm = "STO";
            } else if (receiptType == rksv_receipt_types.RKSV_TRAINING_RECEIPT) {
                sales_counter_aes256_icm = "TRA";
            } else {
                this.sales_counter += this.get_total_with_tax() * 100;
                sales_counter_aes256_icm = this.encryptSalesCounter(this.sales_counter);
            }
            this.pos.config.sales_counter = this.sales_counter;

            var initialSignature;
            if (receiptType == rksv_receipt_types.RKSV_START_RECEIPT) {
                initialSignature = self.pos.config.id.toString();
                console.log("Init receipt");
            } else {
                initialSignature =  self.pos.previous_jws_signature;
            }
            var sha256previousHex = SHA256(initialSignature);
            var sha256previousBytes = aesjs.util.convertStringToBytes(sha256previousHex, "hex");
            var previousOrderPayload = "";
            for (var i = 0; i < sha256previousBytes.length; i++) {
                previousOrderPayload += String.fromCharCode(sha256previousBytes[i]);
            }

            payload =   "_R1-" + certificate.zdaid;                                     // ZDA id
            payload += "_" + this.pos.config.id;                                        // PoS id
            payload +=  "_" + this.uid;                                                 // Receipt number
            payload +=  "_" + moment(this.date).format('YYYY-MM-DDTHH:mm:ss');          // Date/time
            payload +=  "_" + (betrag_satz_normal.toFixed(2)).replace(".",",");         // Amount tax 20%
            payload +=  "_" + (betrag_satz_ermaessigt1.toFixed(2)).replace(".",",");    // Amount tax 10%
            payload +=  "_" + (betrag_satz_ermaessigt2.toFixed(2)).replace(".",",");    // Amount tax 13%
            payload +=  "_" + (betrag_satz_null.toFixed(2)).replace(".",",");           // Amount tax 0%
            payload +=  "_" + (betrag_satz_besonders.toFixed(2)).replace(".",",");      // Amount tax 19%
            payload +=  "_" + base64.encode(sales_counter_aes256_icm);                  // Encrypted turnover counter
            payload +=  "_" + (certificate.serial_hex.toLowerCase());                   // Certificate serial number
            payload +=  "_" + base64.encode(previousOrderPayload.substr(0,8));          // Previous signature
            this.rksv_string = payload;

            return this.rksv_string;
        },
        setSignature: function(signature) {
            this.signature = signature;
            this.qr_string = this.getRKSVString() + "_" + this.signature;
        },

        export_for_printing: function() {
            var company = this.pos.company;
            var receipt = _super_order.export_for_printing.apply(this, arguments);
            if (this.qr_string) {
                var canvas = $(document.createElement('div')).qrcode({width:200, height: 200, text: this.qr_string}).find('canvas').get(0);
                receipt.signatureImage = canvas.toDataURL();
                receipt.payload = this.qr_string;
            }
            receipt.company.display_qrcode = company.display_qrcode;
            return receipt;
        },

    });

    screens.PaymentScreenWidget.include({
        // Sign order
        validate_order: function(force_validation) {
            var self = this;
            if (this.order_is_valid(force_validation)) {
                var order = this.pos.get_order();
                order.sign().always(function() {
                    self.finalize_validation();
                });
            }
        }

    });

    chrome.Chrome.include({
        init: function() {
            var self = this;
            this._super.apply(this, arguments);

            this.pos.ready.done(function(){
                self.check_certificate().done(function() {
                    self.check_initial_receipt(self.pos.config.id).done(function() {
                        self.check_monthly_receipt(self.pos.config.id);
                    })
                });
            });
        },
        check_certificate: function() {
            var self = this;
            var promise = new $.Deferred();
            if (!(this.pos.certificates && this.pos.certificates.length)) {
                this.gui.show_popup('error', {
                    title: _t('Error: Could note find signature certificate'),
                    body: _t('You\'re probably trying to open an existing session created before RKSV module has been installed.\n\n Exiting...'),
                    cancel: function() {
                        self.gui.close();
                    }
                });
            } else {
                promise.resolve();
            }
            return promise;
        },
        check_initial_receipt: function(config){
            var self = this;
            var promise = new $.Deferred();
            var posConfigModel = new Model('pos.config');
            posConfigModel.call('init_check', [config])
                .done(function (result) {
                    if (!result) {
                        promise.reject();
                        self.gui.screen_instances['rksv'].set_mode('init');
                        self.gui.show_screen('rksv');
                    } else {
                        promise.resolve();
                    }
                    return result;
                }).fail(function(result){
                    promise.reject();
                    console.log(result)
                });
            return promise;
        },
        check_monthly_receipt: function(config){
            var self = this;
            var posConfigModel = new Model('pos.config');
            return posConfigModel.call('monthly_check', [config])
                .done(function (result) {
                    if (!result) {
                        self.gui.screen_instances['rksv'].set_mode('monthly');
                        self.gui.show_screen('rksv');
                    }
                    return result;
                }).fail(function(result){
                    console.log(result)
                });
        }
    });

});
