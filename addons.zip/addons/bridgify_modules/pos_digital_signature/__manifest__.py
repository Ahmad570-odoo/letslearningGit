# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
{
    'name': 'PoS: Digital Signature',
    'version': '0.5',
    'category': 'Point of Sale',
    'description': """
PoS: Digital Signature
======================
Digital signature for PoS devices
""",
    'author': "Vadim, bridgify GmbH",
    'website': "http://bridgify.at",
    'license': "OPL-1",
    'depends': ['point_of_sale', 'bridgify', 'bridgify_account_export'],
    'data': [
        'views/views.xml',
        'views/templates.xml',
        'views/report_receipt.xml',
        'views/report_invoice.xml',
        'data/mail_template.xml',
        'data/cron.xml',
        'security/ir.model.access.csv',
    ],
    'qweb': [
        'static/src/xml/pos.xml',
    ],
    'installable': True,
    'auto_install': False,
    'uninstall_hook': "init_report"
}
