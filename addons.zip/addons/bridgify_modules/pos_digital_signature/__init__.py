# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import odoo
import models
from functools import partial
from odoo import api, SUPERUSER_ID


def init_report(cr, registry):
    def recreate_view(dbname):
        db_registry = odoo.modules.registry.RegistryManager.new(dbname)
        with api.Environment.manage(), db_registry.cursor() as cr:
            env = api.Environment(cr, SUPERUSER_ID, {})
            if 'report.pos.order' in env:
                env['report.pos.order'].init()

    cr.after("commit", partial(recreate_view, cr.dbname))
