Charts, Improved.
=================

Improve the charting capabilities of Odoo.

Implemented features:
 * Plot multiple variables (called measures in the odoo client) with bar charts
   using grouped bars.

Planned:
 * Plot multiple measures on line charts
 * Scatter/Bubble chart
 * Sunburst ("grouped Pie chart")
 * Bullet Chart
 * Stacked bar chart
