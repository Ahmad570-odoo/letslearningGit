# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
{
    'name': 'Product Graph View To Tree View',
    'version': '0.5',
    'depends': ['stock'],
    'author': "Est-Pos OÜ",
    'website': "",
    'license': "OPL-1",
    'category': '',
    'description': """
Changes product template default graph view to tree(list) view
    """,
    'data': [
        'views/product_views.xml'
    ],
    'installable': True,
    'auto_install': False,
}
