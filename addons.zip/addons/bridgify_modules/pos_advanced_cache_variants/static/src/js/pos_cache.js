odoo.define('pos_advanced_cache_variants.pos_advanced_cache', function (require) {
    "use strict";
    var core = require('web.core');
    var models = require('point_of_sale.models');
    var Model = require('web.DataModel');
    var _t = core._t;
    var PosDB = require('point_of_sale.DB');

    models.PosDB = models.PosDB.extend({
        add_product_variants: function(products){
            if(!products instanceof Array){
                products = [products];
            }
            for(var i = 0, len = products.length; i < len; i++){
                var product = products[i];
                product.display_name_template = product.display_name;
               // console.log(product);
                product.product_tmpl_id = parseInt(product.product_tmpl_id);
                if (!this.product_variants_by_tmpl_id[product.product_tmpl_id]) {
                    this.product_variants_by_tmpl_id[product.product_tmpl_id] = [];
                }
                this.product_variants_by_tmpl_id[product.product_tmpl_id].push(product);
                this.product_by_id[product.id] = product;

            }
        },
    })

    var posmodel_super = models.PosModel.prototype;
    models.PosModel = models.PosModel.extend({
        load_new_partners: function () {
            var self = this;
            var def = new $.Deferred();
            var fields = ['name', 'street', 'city', 'state_id', 'country_id', 'vat', 'phone', 'zip', 'mobile', 'email', 'barcode', 'write_date', 'property_account_position_id'];
            new Model('res.partner')
                .query(fields)
                .filter([['customer', '=', true], ['write_date', '>', this.db.get_partner_write_date()]])
                .all({'timeout': 3000, 'shadow': true})
                .then(function (partners) {
                    if (self.db.add_partners(partners)) {   // check if the partners we got were real updates
                        def.resolve();
                    } else {
                        def.reject();
                    }
                }, function (err, event) {
                    event.preventDefault();
                    def.reject();
                });
            return def;
        },

        load_server_data: function () {
            var self = this;
            var product_index = _.findIndex(this.models, function (model) {
                return model.model === "product.product";
            });
            var product_model = this.models[product_index];
            product_model.fields.push("display_name_template");
            var product_fields = product_model.fields;
            var product_domain = product_model.domain;
            if (product_index !== -1) {
                this.models.splice(product_index, 1);
            }

            return posmodel_super.load_server_data.apply(this, arguments).then(function () {
                var records = new Model('pos.config').call('get_products_from_cache',
                    [self.pos_session.config_id[0], product_fields, product_domain]);
                self.chrome.loading_message(_t('Loading') + ' product.product', 1);

                return records.then(function (product) {
                    var new_pro = []
                    for (var i = 0; i < product.length; i++) {
                        new_pro.push($.parseJSON(product[i][0]))
                    }
                    self.db.add_product_variants(new_pro);
                });
                self.chrome.loading_message(_t('Loading') + ' res.partner', 1);

            });
        },
    });
    var posmodel_super2 = models.PosModel.prototype;
    models.PosModel = models.PosModel.extend({
        // load_new_partners: function(){
        //     var self = this;
        //     var def  = new $.Deferred();
        //     var fields = ['name','street','city','state_id','country_id','vat','phone','zip','mobile','email','barcode','write_date','property_account_position_id'];
        //     new Model('res.partner')
        //         .query(fields)
        //         .filter([['customer','=',true],['write_date','>',this.db.get_partner_write_date()]])
        //         .all({'timeout':3000, 'shadow': true})
        //         .then(function(partners){
        //             if (self.db.add_partners(partners)) {   // check if the partners we got were real updates
        //                 def.resolve();
        //             } else {
        //                 def.reject();
        //             }
        //         }, function(err,event){ event.preventDefault(); def.reject(); });    
        //     return def;
        // },
        load_server_data: function () {
            var self = this;

            var partner_index = _.findIndex(this.models, function (model) {
                return model.model === "res.partner";
            });
            var partner_model = this.models[partner_index];
            var partner_fields = partner_model.fields;
            var partner_domain = partner_model.domain;
            if (partner_index !== -1) {
                this.models.splice(partner_index, 1);
            }
            return posmodel_super2.load_server_data.apply(this, arguments).then(function () {
                var records = new Model('pos.config').call('get_partner_from_cache',
                    [self.pos_session.config_id[0], partner_fields, partner_domain]);

                self.chrome.loading_message(_t('Loading') + ' res.partner', 1);
                return records.then(function (partners) {
                    var new_partner = []
                    for (var i = 0; i < partners.length; i++) {
                        new_partner.push($.parseJSON(partners[i][0]))
                    }
                    self.partners = new_partner;
                    self.db.add_partners(new_partner);
                });
            });
        },
    });
});
