# -*- coding: utf-8 -*-
{
    'name': "Mobile POS",

    'summary': """
        Mobile view for POS
    """,

    'description': """
    """,

    'author': "StoneLabs",
    'website': "http://www.stonelabs.com",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['point_of_sale'],

    'qweb': [
        'static/src/xml/mobile.xml',
    ],

    'data': [
        'views/assets.xml',
        'views/layout.xml',
    ],

    'installable': True,
    'application': False,
    'auto_install': False,
}