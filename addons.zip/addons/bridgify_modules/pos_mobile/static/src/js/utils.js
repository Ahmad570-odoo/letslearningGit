odoo.define('point_of_sale.mobile.utils', function (require) {
"use strict";

function addCss(name, path, module) {
  path = path || 'src'
  module = module || 'pos_mobile'
  var link = document.createElement('link')
  link.setAttribute('rel', 'stylesheet')
  link.setAttribute('type', 'text/css')
  link.setAttribute('href', '/' + module + '/static/' + path + '/css/' + name + '.css')
  document.getElementsByTagName('head')[0].appendChild(link)
}

return {
  addCss: addCss
}

});