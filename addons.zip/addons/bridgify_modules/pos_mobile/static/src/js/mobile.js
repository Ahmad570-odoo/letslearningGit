odoo.define('point_of_sale.mobile', function (require) {
"use strict";

var deferred = $.Deferred()

deferred.done(function() {

var core = require('web.core');
var screens = require('point_of_sale.screens');
var chrome = require('point_of_sale.chrome');
var models = require('point_of_sale.models');
var addCss = require('point_of_sale.mobile.utils').addCss;
var gui = require('point_of_sale.gui')

var QWeb = core.qweb;
var Gui = gui.Gui;
var _t = core._t;

addCss('bootstrap', 'lib/bootstrap');
addCss('reset');
addCss('header');
addCss('main');
addCss('fix');

var OldPosModel = models.PosModel.extend({});

models.PosModel = models.PosModel.extend({
  initialize: function(session, attributes) {
    OldPosModel.prototype.initialize.call(this, session, attributes)
    this.set({
      'subcategories': [], 
    });
  },

  getSubcategories: function(subcategories) {
    return this.get('subcategories');
  },

  setSubcategories: function(subcategories) {
    this.set({'subcategories': subcategories})
  },

  getOrderlinesByProduct: function(product) {
    return _(this.get_order().get_orderlines())
    .filter(function(orderline) {
      return orderline.product == product
    })
  },

  getQuantityByProduct: function(product) {
    return _(this.get_order().get_orderlines())
    .filter(function(orderline) {
      return orderline.product == product
    })
    .reduce(function(a, b) {
      return a + b.quantity
    }, 0)
  },

  getProductCategory: function(product) {
    var db = this.db
    var categories = this.getSubcategories();
    for (var i = 0; i < categories.length; i++) {
      var category = categories[i];
      if (_.include(db.get_product_by_category(category.id), product))
        return category.id;
    }
    return "other";
  },

  inOrder: function(product) {
    var order = this.get_order()
    return order && _.some(order.get_orderlines(), function(orderline) {
      return orderline.product == product;
    })
  }
})

Gui.include({
  show_popup: function(name, options) {
    this.translateTitle(options);
    this._super(name, options);
    document.body.scrollTop = 0;
  },

  translateTitle: function(options) {
    if (options.title)
      options.title = _t(options.title)
  }
})

chrome.UsernameWidget.include({
  init: function(parent, options) {
    this._super(parent, options)
    this.pos = parent.pos;
  },

  renderElement: function() {
    var self = this;
    this._super()
    this.$el.unbind('click')

    this.addUsers();

    this.$('.dropdown-toggle').dropdown();

    this.$("a").click(function() {
      var user = self.pos.users[$(this).attr('data-value')];
      self.click_username(user);
      self.$("li").removeClass("active")
      $(this).parent().addClass("active")
      self.$(".dropdown-toggle").dropdown("toggle");
    })
  },

  addUsers: function() {
    for (var i = 0; i < this.pos.users.length; i++) {
      var user = this.pos.users[i];
      var element = $("<li>");
      var link = $("<li>") 
      var option = $("<a>")
        .attr("data-value", i)
        .text(user.name)
        .appendTo(element)
      element.appendTo(this.$("ul"))
    }
  },

  click_username: function(user) {
    var self = this;

    if (user !== this.pos.get_cashier() && user.pos_security_pin) {
      this.ask_password(user.pos_security_pin).then(function() {
        self.pos.set_cashier(user);
      });
    } else {
      this.pos.set_cashier(user);
    }
  }
})

var ExitButtonWidget = screens.ActionButtonWidget.extend({
    template: 'ExitButtonWidget',
    button_click: function() {
      var self = this;
      if (!this.confirmed) {
        this.$('a').addClass('confirm');
        this.confirmed = setTimeout(function(){
          self.$('a').removeClass('confirm');
          self.confirmed = false;
        }, 2000);
      } else {
        clearTimeout(this.confirmed);
        this.gui.close();
      }
    },
});

chrome.Chrome.include({
  disable_rubberbanding: function() {
    // TODO enable scroll for elements
  },

  init: function(parent, options) {
    this._super(parent, options);
    this.widgets.push({
      'name':   'close_button',
      'widget': ExitButtonWidget,
      'append':  '.navbar-nav'
    })
  },

  renderElement: function() {
    this._super();
    //TODO use language widget
    this.initLanguageSelector();
  },

  initLanguageSelector: function() {
    this.$('.language-selector .dropdown-toggle').dropdown();
    this.$(".language-selector a").click(function() {
      var language = $(this).attr('data-value');
      self.$(".language-selector li").removeClass("active")
      $(this).parent().addClass("active")
      self.$(".language-selector .dropdown-toggle").dropdown("toggle");
      self.$(".language-selector .dropdown-toggle .lang").text(language);
    })
  }
})

screens.ProductScreenWidget.include({
  start: function() {
    this._super();

    this.createOrderSelectorWidget();
  },

  createOrderSelectorWidget: function() {
    this.orderSelectorWidget = new chrome.OrderSelectorWidget(this);
    this.orderSelectorWidget.replace(this.$('.placeholder-OrderSelectorWidget'));
  },

  renderElement: function() {
    this._super();
    this.initTabs();
    this.initSearchBar();
    this.initSwipe();
    this.openProductsIfEmpty();
  },

  openProductsIfEmpty: function() {
    this.pos.on("change:selectedOrder", function() {
      if (!this.pos.get_order() || this.pos.get_order().get_orderlines().length == 0) 
        this.$("a[data-target='#menu']").tab('show');  
      else
        this.$("a[data-target='#bill']").tab('show');  
    }, this)     
  },

  initTabs: function() {
    var self = this
    this.$('.nav-tabs a').click(function() {
      self.pos.trigger("change:selectedOrder");
      $(this).tab('show');
    })
  },

  initSwipe: function() {
    var hammer = new Hammer(this.el, {})

    hammer.on("swiperight", function() {
      self.$("a[data-target='#bill']").tab('show');
    });
    hammer.on("swipeleft", function() {
      self.$("a[data-target='#menu']").tab('show');
    });
  },

  initSearchBar: function() {
    var self = this;
    this.$(".b-tabs_header_initial .fa-search").click(function() {
      self.$(".b-tabs_header_initial").hide()
      self.$("a[data-target='#menu']").tab('show');
      self.$(".b-tabs_header_search").show()
      self.$(".b-tabs_header_search input").focus();
    });

    this.$(".b-tabs_header_search, .b-tabs_body").click(function() {
      self.$(".b-tabs_header_initial").show()
      self.$(".b-tabs_header_search").hide()
    });

    this.$(".b-tabs_header_search input").click(function() {return false;})

    this.$(".b-tabs_header_search .fa-times").click(function() {
      self.$(".b-tabs_header_search input").val("")
      self.$(".b-tabs_header_search input").focus()
      self.product_categories_widget.clear_search();
      return false;
    });

    this.search_handler = function(event) {
      self.product_categories_widget.search_handler.call(this, event)
    }

    this.el.querySelector(".b-tabs_header_search input").addEventListener("keypress", this.search_handler);
    this.el.querySelector(".b-tabs_header_search input").addEventListener("keydown", this.search_handler);
  },
})

screens.ProductCategoriesWidget.include({
  init: function(parent, options) {
    this._super(parent, options)
    this.start_categ_id = this.pos.db.get_category_childs_ids(this.pos.db.root_category_id)[0];
  },

  renderElement: function() {
    this._super();
    if (this.el.querySelector("select"))
      this.initCategoriesSelector();
  },

  showCategoriesModal: function() {
    var self = this;
    var categories = _.map(this.subcategories, function(category) {
      return {
        label: category.name,
        item: category
      }
    })
    this.gui.show_popup('selection', {
      title: 'Select category',
      list: categories,
      confirm: function(category) { 
        self.set_category(category);
        self.renderElement();
      },
      cancel:  function() {},
    });
  },

  initCategoriesSelector: function() {
    var self = this;

    this.el.querySelector("select").addEventListener('change', function(event) {
      var id = Number($(event.target).val());
      self.set_category(self.pos.db.get_category_by_id(id));
      self.renderElement();
    });

    this.addMobileChromeFix();

    if (this.category.id != 0)
      this.el.querySelector('select').value = this.category.id
  },

  addMobileChromeFix: function() {
    var self = this;

    this.el.querySelector(".select-fix").addEventListener('click', function(event) {
      self.showCategoriesModal();
    });
  },

  render_category: function(category) {
    return this._super(category, false);
  },

  set_category: function(category) {
    this._super();
    var subcategories = this.subcategories;
    this._super(category);
    this.pos.setSubcategories(this.subcategories);
    this.subcategories = subcategories;
  },
})

chrome.OrderSelectorWidget.include({
  init: function(parent, options) {
    this._super(parent, options);
    this.offset = 0;
  },

  renderElement: function() {
    this.checkOffset();
    this._super();
    this.initButtons();
  },

  initButtons: function() {
    var self = this;

    this.$('.b-pagination_number').click(function(event){
      self.order_click_handler(event,$(this));
    });
    this.$('.b-pagination_right').click(function(event){
      self.toNextPage(event,$(this));
    });
    this.$('.b-pagination_left').click(function(event){
      self.toPreviousPage(event,$(this));
    });
    this.$('.b-pagination_plus').click(function(event){
      self.offset = 0;
      self.neworder_click_handler(event,$(this));
    });
    this.$('.b-pagination_del').click(function(event){
      self.offset = 0;
      self.deleteorder_click_handler(event,$(this));
    });
  },

  checkOffset: function() {
    if (this.pos.get_order_list().length <= this.offset + 2)
      this.offset = 0;
  },

  toNextPage: function(event, element) {
    if (!this.is_end())
      this.offset++;
    this.renderElement();
  },

  toPreviousPage: function(event, element) {
    if (!this.is_beginning())
      this.offset--;
    this.renderElement();
  },

  get_order_list: function() {
    var size = 2;
    if (this.is_beginning() || this.is_end())
      size = 3
    return this.pos.get_order_list()
      .reverse()
      .slice(this.offset, this.offset + size)
  },

  is_beginning: function() {
    return this.offset == 0;
  },

  is_end: function() {
    return (this.offset + 3) >= this.pos.get_order_list().length;
  }
})

screens.OrderWidget.include({
  renderElement: function() {
    this._super();
  },

  update_summary: function() {
    this._super();

    var total = this.el.querySelector(".summary .total .value").textContent ;
    var taxes = this.el.querySelector(".summary .total .subentry .value").textContent;

    if (total.length == 0)
      total = "0.00"
    if (taxes.length == 0)
      taxes = "0.00"

    this.el.querySelector('.b-all_cost .b-total span').textContent = total;
    this.el.querySelector('.b-all_cost .b-all_cost_last span').textContent = taxes;
  }
})

screens.ProductListWidget.include({
  categories: [],

  init: function(parent, options) {
    var self = this;
    var clickAction = options.click_product_action;
    options.click_product_action = function(product) {
      clickAction(product);
      self.render_product(product); 
    }
    this._super(parent, options);
    this.bindCategories();
  },

  bindCategories: function() {
    this.pos.bind('change:subcategories', function() {
      this.categories = this.pos.getSubcategories();
    }, this);
  },

  renderElement: function() {
    this._super();
    this.loadProducts();
    this.initAccordionsMenu();
  },

  loadProducts: function() {
    var self = this;
    _(this.product_list).each(function(product) {
      var category = self.pos.getProductCategory(product)
      var id = 'ul[data-category-id="' + category + '"]';
      var node = self.render_product(product);
      self.initPressEvent(node, product);
      $(self.el.querySelector(id)).append(node)
    })
  },

  initPressEvent: function(node, product) {
    var self = this;
    // TODO get rid of this crutch
    if(!node.hammer) {
      var hammer = new Hammer(node, {domEvents: true})

      hammer.on("pressup", function() {
        $(node).addClass("edited")
        $(node).find("input").val(self.pos.getQuantityByProduct(product));
      })

      $(node).find('input').click(function() {
        return false;
      });

      $(node).find('input').change(function() {
        var value = isNaN(parseInt($(this).val())) ? 0 : parseInt($(this).val());
        _(self.pos.getOrderlinesByProduct(product)).each(function(orderline) {
          self.pos.get_order().remove_orderline(orderline);
        })
        self.pos.get_order().add_product(product);
        self.pos.getOrderlinesByProduct(product)[0].set_quantity(value);
        $(node).removeClass("edited");
        self.render_product(product);
      });

      $(node).find('.glyphicon-remove').click(function() {
        $(node).removeClass("edited")
        _(self.pos.getOrderlinesByProduct(product)).each(function(orderline) {
          self.pos.get_order().remove_orderline(orderline);
        })
        self.render_product(product);
        return false;
      });

      node.hammer = true;
    }
  },

  initAccordionsMenu: function() {
    var accordionsMenu = $(this.el).find('.cd-accordion-menu');
    accordionsMenu.each(function(){
      var accordion = $(this);
      accordion.on('change', 'input[type="checkbox"]', function(){
        var checkbox = $(this);
        if (checkbox.prop('checked'))
          checkbox.siblings('ul').attr('style', 'display:none;').slideDown(300)
        else
          checkbox.siblings('ul').attr('style', 'display:block;').slideUp(300);
      });
    });
  },

  render_product: function(product){
    var node = this._super(product);

    if (this.pos.inOrder(product)) {
      $(node).find(".menu-added").removeClass("fix-hidden")
      $(node).find(".menu-added .amount").text(this.pos.getQuantityByProduct(product))
      $(node).find(".menu-price").addClass("fix-hidden");
    }
    else {
      $(node).find(".menu-price").removeClass("fix-hidden")
      $(node).find(".menu-added").addClass("fix-hidden")
    }

    return node;
  }
})

screens.PaymentScreenWidget.include({
  click_paymentmethods: function(id) {
    this._super(id);
    var offset = this.$(".payment-numpad").height() + this.$(".payment-numpad").offset().top
    this.$('.full-content').scrollTop(offset);
  }
})

})

if (isMobile())
  deferred.resolve();
else
  deferred.reject();

return deferred;
});
