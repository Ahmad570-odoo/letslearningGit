# -*- coding: utf-8 -*-

import odoo
from odoo import http
from odoo.addons.point_of_sale.controllers.main import PosController
from odoo.http import request

from pdb import set_trace
 
class PosMobileController(PosController):

  @http.route('/pos/web', type='http', auth='user')
  def pos_web(self, debug=False, **k):
    # unload_modules
    return PosController.pos_web(self, debug, **k)