# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.
{
    'name': 'PoS: A-Trust Interface',
    'version': '0.5',
    'depends': ['pos_digital_signature'],
    'author': "Vadim, bridgify GmbH",
    'website': "http://bridgify.at",
    'license': "OPL-1",
    'category': 'Point of Sale',
    'description': """
PoS Digital Signature: A-Trust interface
========================================
    """,
    'data': [],
    'depends': ['pos_digital_signature'],
    'installable': True,
    'auto_install': False,
}
