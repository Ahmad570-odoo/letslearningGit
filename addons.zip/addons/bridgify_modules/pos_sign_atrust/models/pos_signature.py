# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import os
import json
import logging
import requests
from odoo import models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    with open(os.path.dirname(os.path.abspath(__file__)) + '/../credentials.json') as data_file:
        data = json.load(data_file)

        class ATrust(models.AbstractModel):
            _inherit = 'pos.signature'
            headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8'}

            @classmethod
            def _build_model(cls, pool, cr):
                cls.url = data.get('url')
                cls.verify = data.get('verify', True)
                cls.partner_login = data.get('partner_login')
                cls.partner_password = data.get('partner_password')
                cls.product_version = data.get('product_version', 0)
                cls.demo = data.get('demo')
                return super(ATrust, cls)._build_model(pool, cr)

            @staticmethod
            def _translate(data):
                tr = {
                    'username': 'user',
                    'Signaturzertifikat': 'signature',
                    'Zertifikatsseriennummer': 'serial',
                    'ZertifikatsseriennummerHex': 'serial_hex',
                    'Zertifizierungsstellen': 'authorities'
                }
                return {tr.get(key, key): data[key] for key in data}

            def create_certificate(self):
                return

            def get_certificate(self, user, password):
                url = self.url + user + '/Certificate'
                r = requests.get(url, headers=self.headers, verify=self.verify)
                _logger.info(r.text)
                data = r.json()
                return self._translate(data)

            def create_session(self, user, password):
                url = self.url + 'Session/' + user
                payload = {'password' : password}
                r = requests.put(url, data=json.dumps(payload), headers=self.headers, verify=False)
                _logger.info(r.text)
                r.raise_for_status()
                sessionInfo = r.json()
                return sessionInfo

            def sign(self, sessionInfo, payload):
                _logger.info(sessionInfo)
                url = self.url + 'Session/' + sessionInfo['sessionid'] + '/Sign/JWS'
                payload = {'sessionkey': sessionInfo['sessionkey'], "jws_payload": payload}
                _logger.info(url)
                _logger.info(payload)
                r = requests.post(url, data=json.dumps(payload), headers=self.headers, verify=False)
                _logger.info(r.text)
                return r.json()['result']

            def create_user_cert(self, uid, email, classification_key_type):
                if self.demo:
                    data = self.demo
                else:
                    payload = {
                        'product_version': self.product_version,
                        'partner_password': self.partner_password,
                        'classification_key_type': classification_key_type,
                        'classification_key': uid,
                        'email': email
                    }
                    _logger.info(payload)
                    url = self.url + self.partner_login + '/Account'
                    _logger.info(url)
                    r = requests.post(url, data=json.dumps(payload), headers=self.headers, verify=False)
                    if not r.ok:
                        _logger.error("A-trust error: %s. Reason: %s" % (r.text, r.reason))
                        raise UserError("A-trust error. Reason: %s" % (r.reason,))
                    _logger.info(r.text)
                    data = r.json()
                return self._translate(data)

except IOError:
    _logger.error('Can\'t read credentials.json: Skipping a-trust interface')
except Exception, e:
    _logger.error('Skipping a-trust interface: %s', e)
finally:
    _logger.info('Loading a-trust interface')
