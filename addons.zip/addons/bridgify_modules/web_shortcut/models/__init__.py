# -*- coding: utf-8 -*-
# Copyright 2014 Acsone SA/NV (http://www.acsone.eu)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import web_shortcut
from . import ir_ui_menu
