`2.0.0`
-------

- **ADD:** Support of latest version of hw_printer_network, which has asynchroneous checking of network status now

`1.0.0`
-------

- Init version
