from odoo import api, fields, models
from odoo.exceptions import ValidationError


class ProductProductInheritFields(models.Model):
    _inherit = "product.product"

    PZN = fields.Char(string="PZN", unique=True, index=True)
    art_nr = fields.Char(string="Art Nr")
    EAN = fields.Char(string="EAN")

    @api.constrains('PZN')
    def _check_unique_PZN(self):
        for record in self:
            if record.PZN:
                existing_record = self.env['product.product'].search([('PZN', '=', record.PZN), ('id', '!=', record.id)])
                if existing_record:
                    raise ValidationError("PZN value must be unique. This value is already used in another record.")
