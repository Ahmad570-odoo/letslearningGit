/*
 * Copyright 2017 bridgify GmbH: See LICENSE file for full copyright and licensing details.
 */
odoo.define('pos_product_variants', function (require){
"use strict"

    var round_pr = require('web.utils').round_precision;
    var screens = require('point_of_sale.screens');
    var models = require('point_of_sale.models');
    var PosDB = require('point_of_sale.DB');
    var core = require('web.core');
    var QWeb = core.qweb;
    var _t = core._t;

    var selectedCourse = null;

    var _product_search_string = PosDB.prototype._product_search_string;
    PosDB.include({
        init : function(options) {
            this._super(options);
            this.product_variants_by_tmpl_id = {};
        },
        add_products: function(products){
            if(!products instanceof Array){
                products = [products];
            }

            for(var i = 0, len = products.length; i < len; i++){
                var product = products[i];
                product.product_tmpl_id = [product.id];
                product.id = product.product_variant_ids[0];
                products[i] = product;
            }
            // TODO: WTF?
            var bak = this.product_by_id;
            this.product_by_id = {};

            this._super(products);

            this.product_by_id = bak;
            // overwrite display name
            for(var i = 0, len = products.length; i < len; i++){
                var product = products[i];
                if(typeof this.product_by_id[product.id] === 'undefined')
                    continue;
                this.product_by_id[product.id].display_name_template = product.display_name;
            }
        },
        add_product_variants: function(products){
            if(!products instanceof Array){
                products = [products];
            }
            for(var i = 0, len = products.length; i < len; i++){
                var product = products[i];
               // console.log(product);
                product.product_tmpl_id = parseInt(product.product_tmpl_id);
                if (!this.product_variants_by_tmpl_id[product.product_tmpl_id]) {
                    this.product_variants_by_tmpl_id[product.product_tmpl_id] = [];
                }
                this.product_variants_by_tmpl_id[product.product_tmpl_id].push(product);
                this.product_by_id[product.id] = product;
            }
        },
        get_product_variants_by_id : function(product_id) {
            var product = this.get_product_by_id(product_id);
            var self = this;
            return this.product_variants_by_tmpl_id[product.product_tmpl_id];
        },
        _product_search_string: function(product){
            var variants = this.product_variants_by_tmpl_id[product.product_tmpl_id];
            var str = (variants || []).map(function(v) {return v.display_name;}).join('|');
            if (product.barcode) {
                str += '|' + product.barcode;
            }
            if (product.default_code) {
                str += '|' + product.default_code;
            }
            if (product.description) {
                str += '|' + product.description;
            }
            if (product.description_sale) {
                str += '|' + product.description_sale;
            }
            str  = product.id + ':' + str.replace(/:/g,'') + '\n';
            return str;
        },
    });

    models.load_models([{
        model:  'product.template',
        fields: ['display_name', 'list_price','price','pos_categ_id', 'taxes_id', 'barcode', 'image_length',
                 'to_weight', 'uom_id', 'uos_id', 'uos_coeff', 'mes_type', 'description_sale', 'description',
                 'product_variant_ids'],
        order:  ['sequence','name'],
        domain: [['sale_ok','=',true],['available_in_pos','=',true]],
        context: function(self){ return { pricelist: self.pricelist.id, display_default_code: false }; },
        loaded: function(self, products){
            self.db.add_products(products);
        },
    }]);

    var PosModelSuper = models.PosModel;
    models.PosModel = models.PosModel.extend({
        initialize : function(session, attributes) {
            for (var i = 0; i < this.models.length; i++) {
                var currentModel = this.models[i];
                if (currentModel.model === 'product.product') {
                    currentModel.loaded = function(self, products) {
                        self.db.add_product_variants(products);
                    }
                }
                this.models[i] = currentModel;
            }
            PosModelSuper.prototype.initialize.call(this, session, attributes);
        }
    });

    screens.ProductListWidget.include({
        init : function(parent, options) {
            var self = this;
            this._super(parent, options);
            this.click_product_handler = function(event){
                var variants = self.pos.db.get_product_variants_by_id(this.dataset['productId']);
                if (variants.length > 1) {
                    var listOfVariants = [];
                    for (var i = 0; i < variants.length;i++) {
                        listOfVariants.push({item: variants[i], label : variants[i].display_name, right_label : variants[i].price});
                    }
                    self.gui.show_popup('selection',{
                        'title': _t('Select variant'),
                        'list': listOfVariants,
                        'confirm': function(val) {
                            options.click_product_action(val);
                        },

                    });

                } else {
                    options.click_product_action(variants[0]);
                }

            };
        }
    });

    screens.ProductCategoriesWidget.include({
        perform_search: function(category, query, buy_result){
            var products;
            if(query){
                products = this.pos.db.search_product_in_category(category.id,query);
                if(buy_result && products.length === 1){
                    // Search inside variants
                    var variants = this.pos.db.get_product_variants_by_id(products[0].id);
                    variants = (variants || []).filter(function(variant){
                        var str = _product_search_string(variant);
                        return str.search(query) !== -1;
                    });
                    var product = variants.length >= 1 ? variants[0] : products[0];
                    this.pos.get_order().add_product(product);
                    this.clear_search();
                }else{
                    this.product_list_widget.set_product_list(products);
                }
            }else{
                products = this.pos.db.get_product_by_category(this.category.id);
                this.product_list_widget.set_product_list(products);
            }
        },
    });
});

