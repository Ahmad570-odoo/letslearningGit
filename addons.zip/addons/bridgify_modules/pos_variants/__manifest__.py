# -*- coding: utf-8 -*-

{
    'name': 'Point of Sale Variants',
    'version': '1.0',
    'category': 'Point of Sale',
    'sequence': 6,
    'summary': 'Different handling of product variants in POS module',
    'description': """
Point of Sale Variants
=======================
When using product variants, now the main product is only shown in POS and on select, one of the variants can be chosen.
""",
    'author': 'bridgify GmbH',
    'website': "http://bridgify.at",
    'license': "OPL-1",
    'depends': ['point_of_sale'],
    'data': [
        'views/templates.xml'
    ],
    'qweb': [
        'static/src/xml/pos.xml',
    ],
    'demo': [
        'demo/product_attribute_value.yml',
        'demo/product_product.yml',
        'demo/res_groups.yml',
    ],
    'installable': True,
    'auto_install': False,
}
