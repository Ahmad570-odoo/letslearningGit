# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class PosConfig(models.Model):
    _inherit = 'pos.config'

    iface_print_summary = fields.Boolean(string='Sales Summary',
                                         help='Print sales summary when exiting session?', default=True)
