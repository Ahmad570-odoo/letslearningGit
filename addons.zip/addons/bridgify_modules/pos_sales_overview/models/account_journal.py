# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import models, fields


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    allow_refund = fields.Selection([('cash', 'Cash Journal'), ('bank', 'This Journal'), ('disable', 'Disable')],
                                    string='Allow Refund', required=True, copy=False, default='cash',
        help="Use this field to setup refunding policy.\n"
             " * 'Cash Journal' (default) is used when refund is issued to your cash journal, i.e. a customer gets cash refund.\n"
             " * 'This Journal' is used if you'd like to issue a manual bank refund and allows negative amounts posted to this journal.\n"
             " * Use 'Disable' value to disable refunding orders paid with this payment method, for example vouchers.")
