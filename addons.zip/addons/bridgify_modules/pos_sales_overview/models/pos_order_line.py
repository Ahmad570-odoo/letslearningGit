# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'

    """ This is a dirty trick to quickly port the module 
    """
    # TODO: refactor

    price_subtotal = fields.Float(store=True)
    price_subtotal_incl = fields.Float(store=True)
