# -*- coding: utf-8 -*-

import logging
import itertools

from pprint import pprint
from dateutil.parser import parse
from odoo import api, fields, models, _
from datetime import datetime, timedelta

_logger = logging.getLogger(__name__)

DEBUG_ENABLED = 0


class PosSession(models.Model):
    _inherit = 'pos.session'

    def _report_add_where_hook(self):
        try:
            return super(PosSession, self)._report_add_where_hook()
        except AttributeError:
            return ''

    @api.model
    def fetch_orders(self, pos_session_id, pos_config_id, date_from, date_to, include_times=False):

        if isinstance(pos_config_id, (int, long)):
            pos_config_id = [pos_config_id]

        pos_config_id = tuple(pos_config_id)

        date_start = date_stop = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        try:
            date_start = parse(date_from, dayfirst=True)
            date_stop = parse(date_to, dayfirst=True)
        except ValueError:
            pass
        date_stop = max(date_stop, date_start)

        _logger.info(fields.Datetime.to_string(date_start))
        _logger.info(fields.Datetime.to_string(date_stop))

        if include_times:
            pos_orders = self.browse(pos_session_id).order_ids if pos_session_id > 0 else self.env['pos.order'].search([
                ('config_id', 'in', pos_config_id),
                ('date_order', '>=', fields.Datetime.to_string(date_start)),
                ('date_order', '<=', fields.Datetime.to_string(date_stop))
            ])
        else:
            pos_orders = self.browse(pos_session_id).order_ids if pos_session_id > 0 else self.env['pos.order'].search([
                ('config_id', 'in', pos_config_id),
                ('date_order', '>=',
                 fields.Datetime.to_string(date_start.replace(hour=0, minute=0, second=0, microsecond=0))),
                ('date_order', '<=',
                 fields.Datetime.to_string(date_stop.replace(hour=0, minute=0, second=0, microsecond=0)
                                           + timedelta(hours=23, minutes=59, seconds=59)))
            ])
        pos_orders = pos_orders.filtered(self._report_filter_hook())

        ##############################################################################################################
        # Products:                                                                                                  #
        ##############################################################################################################
        pos_order_lines = pos_orders.mapped('lines')
        products = pos_order_lines.mapped('product_id')
        sales_orders = []

        for product in products.sorted('name'):
            positive = {
                 'subtotal_incl': 0.0,
                 'amount': 0.0,
                 'name': product.name,
                 'variant_name': ', '.join(product.attribute_value_ids.mapped('name')),
                 'uom_id': product.uom_id.id
                 }
            negative = {
                 'subtotal_incl': 0.0,
                 'amount': 0.0,
                 'name': product.name,
                 'variant_name': ', '.join(product.attribute_value_ids.mapped('name')),
                 'uom_id': product.uom_id.id
                 }
            for line in pos_order_lines.filtered(lambda l: l.product_id == product):
                if line.qty > 0:
                    positive['subtotal_incl'] += line.price_subtotal_incl
                    positive['amount'] += line.qty
                else:
                    negative['subtotal_incl'] += line.price_subtotal_incl
                    negative['amount'] += line.qty

            if positive['amount'] > 0:
                sales_orders.append(positive)
            if negative['amount'] < 0:
                sales_orders.append(negative)

        #this part sums sales and refunds together.
        # sales_orders = [{'subtotal_incl': sum([line.price_subtotal_incl for line in pos_order_lines.filtered(lambda l: l.product_id == product)]),
        #                  'amount': sum([line.qty for line in pos_order_lines.filtered(lambda l: l.product_id == product)]),
        #                  'name': product.name,
        #                  'variant_name': ', '.join(product.attribute_value_ids.mapped('name')),
        #                  'uom_id': product.uom_id.id} for product in products.sorted('name')]

        product_count = sum([p['amount'] for p in sales_orders])
        sales_total = sum([p['subtotal_incl'] for p in sales_orders])

        filter_by_session = False

        if pos_session_id > 0:
            filter_by_session = True

        ##############################################################################################################
        # Taxes:                                                                                                     #
        ##############################################################################################################
        def sum_taxes(total, item):
            tax = total.setdefault(item.get('description') or item.get('name'), {'base': 0.0, 'amount': 0.0})
            tax.update({'base': tax['base'] + item['base'], 'amount': tax['amount'] + item['amount']})
            return total
        tax_details = reduce(sum_taxes, [tax for order in pos_orders for tax in order._get_tax_amount_by_group()], {})
        taxes = [{'description': _('Sale TOTAL'), 'sum': sum([tax['base'] + tax['amount'] for tax in tax_details.values()])}]
        [taxes.append({'description': _('of that ') + name, 'sum': tax['base'] + tax['amount']}) for name, tax in tax_details.items()]
        taxes.append({'description': _('Total Without Tax'), 'sum': sum([tax['base'] for tax in tax_details.values()])})
        taxes.append({'description': _('Total Tax'), 'sum': sum([tax['amount'] for tax in tax_details.values()])})
        [taxes.append({'description': _('of that ') + name, 'sum': tax['amount']}) for name, tax in tax_details.items()]

        ##############################################################################################################
        # Refunds:                                                                                                   #
        ##############################################################################################################
        refund_lines = self.env['pos.order.line'].search([('order_id', 'in', pos_orders.ids), ('qty', '<', 0)])
        returned_product_count = sum([line.qty for line in refund_lines])
        refunds = [{'description': _('Refund TOTAL'), 'sum': sum([line.price_subtotal_incl for line in refund_lines])}] \
            if refund_lines else []
        tax_details = reduce(sum_taxes, [tax for line in refund_lines for tax in
                                         line.tax_ids_after_fiscal_position.compute_all(
                                             line.price_unit, line.order_id.pricelist_id.currency_id,
                                             line.qty,product=line.product_id,
                                             partner=line.order_id.partner_id)['taxes']], {})
        [refunds.append({'description': _('of that ') + name, 'sum': tax['base'] + tax['amount']}) for name, tax in tax_details.items()]

        # TODO: further refactor all that crap
        # ########################################################################################################### #
        # Sales Journal                                                                                               #
        #                                                                                                             #
        # Get the sales summary of the different payments methods (Cash, Bank, etc.)                                  #
        # ########################################################################################################### #
       
        sql = ("select journal.id as journal_id, " +
                    "journal.name as journal_name, " +
                    #"journal.pos_payment_description as journal_pos_name, " +
                    "SUM(CASE WHEN amount >0 THEN amount ELSE 0 END) as amount_in, " +
                    "SUM(CASE WHEN amount <0 THEN amount ELSE 0 END) as amount_out, " +
                    "SUM(amount) as amount_total " +
               "from account_bank_statement b " +
                    "INNER JOIN account_bank_statement_line AS bl ON b.id = bl.statement_id " +
                    "INNER JOIN account_journal as journal ON (b.journal_id=journal.id) "+
                    "INNER JOIN pos_session ON (b.pos_session_id=pos_session.id) WHERE " )

        if filter_by_session:
            sql += "b.pos_session_id=%s AND "
        else:
            sql += "pos_session.config_id IN %s AND "

        sql += (" date_trunc('day',bl.create_date) between to_date(%s, 'DD.MM.YYYY') AND to_date(%s, 'DD.MM.YYYY') " +
               "GROUP BY journal.id")
        
        if DEBUG_ENABLED:
           print("sales journal:\n")
           pprint(sql)
           print("\n\n")
           
        if filter_by_session:
            self.env.cr.execute(sql, (pos_session_id,date_from, date_to))
        else:
            self.env.cr.execute(sql, (pos_config_id, date_from, date_to))
        sales_journal = self.env.cr.dictfetchall()


        # ########################################################################################################### #
        # Sales Cashbox                                                                                               #
        #                                                                                                             #
        # Get the sales summary of the cashbox                                                                        #
        # ########################################################################################################### #

        sql = ("select balance_start as cash_start, " +
                    "balance_end as cash_end, " +
                    "SUM(CASE WHEN pos_statement_id IS NULL THEN amount ELSE 0 END) as amount_inout"
               " FROM account_bank_statement AS b " +
               "INNER JOIN pos_session ON (b.pos_session_id=pos_session.id) " +
               "INNER JOIN account_bank_statement_line AS bl ON b.id = bl.statement_id " +
               "INNER JOIN account_journal as journal ON (b.journal_id=journal.id) WHERE journal.type = 'cash' AND ")

        if filter_by_session:
            sql += "pos_session_id=%s AND "
        else:
            sql += "pos_session.config_id IN %s AND "

        sql += (" date_trunc('day',b.date) between to_date(%s, 'DD.MM.YYYY') AND to_date(%s, 'DD.MM.YYYY') " +
               " GROUP BY b.id")

        if DEBUG_ENABLED:
           print("sales cash:\n")
           pprint(sql)
           print("\n\n")

        sales_cashbox = []

        if filter_by_session:
            self.env.cr.execute(sql, (pos_session_id,date_from, date_to))
        else:
            self.env.cr.execute(sql, (pos_config_id, date_from, date_to))

        for res in self.env.cr.fetchall():
            cash = {'balance_start':res[0],
                    'balance_end':res[1],
                    'inout' : res[2]
                    }

            sales_cashbox.append(cash);

        # ########################################################################################################### #
        # Sales users:                                                                                                #
        #                                                                                                             #
        # Get the sales summary for each user                                                                         #
        # ########################################################################################################### #
        sql = ("select res_users.id, res_partner.name," + 
                    " res_users.signature," +
                    " SUM(pos_order_line.price_subtotal) as subtotal," +
                    " SUM(pos_order_line.price_subtotal_incl) as subtotal_incl" +
                " from pos_order INNER JOIN res_users ON (pos_order.user_id=res_users.id) " +
                    "INNER JOIN res_partner ON res_users.partner_id = res_partner.id " +
                    "INNER JOIN pos_session ON (pos_order.session_id=pos_session.id) " +
                    "INNER JOIN pos_order_line ON (pos_order.id=pos_order_line.order_id) WHERE ")

        if filter_by_session:
            sql += "session_id=%s AND "
        else:
            sql += "pos_session.config_id IN %s AND "

        # Hook for pos_digital_signature to exclude rksv receipts
        sql += self._report_add_where_hook()

        sql += (" date_trunc('day',pos_order.date_order) between to_date(%s, 'DD.MM.YYYY') AND to_date(%s, 'DD.MM.YYYY') " +
               "GROUP BY res_users.id, res_partner.id;")
        
        sales_users = []

        if filter_by_session:
            self.env.cr.execute(sql, (pos_session_id, date_from, date_to))
        else:
            self.env.cr.execute(sql, (pos_config_id, date_from, date_to))
        
        for res in self.env.cr.fetchall():
            user = {
                     'id': res[0], 
                     'login_name': res[1], 
                     'user_signature': res[2], 
                     'subtotal': res[3], 
                     'subtotal_incl' : res[4] 
            }
            sales_users.append(user)

        if DEBUG_ENABLED:
           print("sales_users:\n")
           pprint(sql)
           print("\n\n")
        
        # ########################################################################################################### #
        # sales by category:                                                                                          #
        #                                                                                                             #
        # ########################################################################################################### #
        sql = ("select description, id, sum(subtotal_incl) FROM (select pos_category.name as description, pos_category.id as id, " +
                    "round(SUM(pos_order_line.price_subtotal_incl),2) as subtotal_incl " +
                "from pos_order " + 
                    "INNER JOIN pos_order_line ON (pos_order.id=pos_order_line.order_id) " +
                    "INNER JOIN pos_session ON (pos_order.session_id=pos_session.id) " +
                    "INNER JOIN product_product ON (pos_order_line.product_id=product_product.id) " +
                    "INNER JOIN product_template ON (product_product.product_tmpl_id=product_template.id) " +
                    "LEFT JOIN pos_category ON (product_template.pos_categ_id=pos_category.id) WHERE ")

        if filter_by_session:
            sql += "session_id=%s AND "
        else:
            sql += "pos_session.config_id IN %s AND "

        # Hook for pos_digital_signature to exclude rksv receipts
        sql += self._report_add_where_hook()

        sql += (" date_trunc('day',pos_order.date_order) between to_date(%s, 'DD.MM.YYYY') AND to_date(%s, 'DD.MM.YYYY') " +
                "GROUP BY pos_category.id")

        sql += " , pos_order.id) as foo group by id, description"

        if DEBUG_ENABLED:   
           print("category:\n")
           pprint(sql)
           print("\n\n")

        sales_category = []

        if filter_by_session:
            self.env.cr.execute(sql, (pos_session_id,date_from, date_to))
        else:
            self.env.cr.execute(sql, (pos_config_id, date_from, date_to))
        
        for res in self.env.cr.fetchall():
            entry = {
                     'name': res[0] if res[0] else '(Keine Kategorie)', 
                     'subtotal_incl' : res[2] 
            }
            sales_category.append(entry)

        ###############################################################################################################
        # Peak sales hour                                                                                             #
        ###############################################################################################################
        peak_sales_hour = ''
        group_per_hour = itertools.groupby(pos_orders.sorted("date_order"), lambda r: r.date_order[:13])
        sale_per_hour = {k: sum(itertools.imap(lambda r: r.amount_total, g)) for k, g in group_per_hour}
        if len(sale_per_hour):
            peak_sales_hour, peak_volume = max(sale_per_hour.iteritems())
            peak_sales_hour = fields.Datetime.context_timestamp(self, parse(':'.join((peak_sales_hour, '00'))))
            peak_sales_hour = datetime.strftime(peak_sales_hour, '%H:%M')

        result = {
                  'sales_orders':           sales_orders, 
                  'sales_total':            sales_total, 
                  'sales_taxes':            taxes, 
                  'refunds':                refunds,
                  'returned_product_count': returned_product_count,
                  'sales_journal':          sales_journal,
                  'sales_cashbox':          sales_cashbox,
                  'sales_users':            sales_users,
                  'max_sales_hour':         peak_sales_hour,
                  'sales_category':         sales_category,
                  'product_count':          product_count,
                  'order_cnt':              len(pos_orders)
        }

        return result
