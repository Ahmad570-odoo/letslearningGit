# -*- coding: utf-8 -*-

{
    'name': 'Point of Sale - Sales Overview',
    'version': '0.4',
    'category': 'Point of Sale',
    'sequence': 7,
    'summary': 'Sales overview and refund',
    'description': """
Sales Overview
==============
CHANGELOG:
    20180514: 0.3 Include VAT details and refunds in report

    20180619: 0.4 Enable refunds to be booked to bank journals. 
    Disallow refunding orders paid with certain payment methods, such as voucher  
""",
    'author': "Vadim, bridgify GmbH",
    'website': "http://bridgify.at",
    'license': "OPL-1",
    'depends': ['point_of_sale', 'bridgify', 'report'],
    'data': [
        'views/templates.xml',
        'views/pos_config_view.xml',
        'views/account_journal.xml',
        'views/sales_overview.xml',
        'views/sales_overview_report.xml',
        'report/sales_overview_report.xml',
    ],
    'qweb': [
        'static/src/xml/sales-overview.xml',
        'static/src/xml/refund.xml',
    ],
    'installable': True,
    'auto_install': False,
}
