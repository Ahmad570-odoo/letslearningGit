/*
 * Copyright 2017 bridgify GmbH: See LICENSE file for full copyright and licensing details.
 */
odoo.define('bridgify.pos_overview', function (require){
"use strict"

    var screens = require('point_of_sale.screens');
    var devices = require('point_of_sale.devices');
    var models = require('point_of_sale.models');
    var gui = require('point_of_sale.gui');
    var Model = require('web.DataModel');
    var utils = require('web.utils');
    var core = require('web.core');
    var session = require('web.session');
    var QWeb = core.qweb;
    var _t = core._t;
    // TODO refactor extend to include where needed, require hierarchy, remove copy paste functions (wrap_line, get_separator_line)
    String.prototype.wordWrap = function(m, b, c) {
        var i, j, l, s, r;
        if(m < 1)
            return this;
            
        for(i = -1, l = (r = this.split("\n")).length; ++i < l; r[i] += s)
            for(s = r[i], r[i] = ""; s.length > m; r[i] += s.slice(0, j) + ((s = s.slice(j)).length ? b : ""))
                j = c === 2 || (j = s.slice(0, m + 1).match(/\S*(\s)?$/))[1] ? m : j.input.length - j[0].length
                || c === 1 && m || j.input.length + (j = s.slice(m).match(/^\S*/)).input.length;
        return r.join("\n");
    };
    
    var OverviewScreenWidget = screens.ScreenWidget.extend({
            
        template:'SalesOverviewScreen',
        
        init: function(parent,options) {

            this.reset();
            this._super(parent,options);
            this.hidden = false;
            this.mode = 'session';

            this.pos_session_id = this.pos.pos_session.id;
            this.pos_config_id = this.pos.config.id;

            this.today = this.date_from = this.date_to = moment(new Date()).format('DD.MM.YYYY');
            this.beginning_of_time = moment({ y: 1900 }).format('DD.MM.YYYY');
            this.end_of_time = moment().add(200, "y").format('DD.MM.YYYY');
            this.firstWeekDay = moment().startOf('isoweek').format('DD.MM.YYYY');
            this.show_products = true;
            //Date Picker options
            this.datepicker_options = {
                language: session.user_context.lang,
                format: 'DD.MM.YYYY',
                pickTime: false,
                defaultDate: this.today,
                useSeconds: false,
                startDate: moment({ y: 1900 }),
                endDate: moment().add(200, "y"),
                calendarWeeks: false,
                icons : {
                    time: 'fa fa-clock-o',
                    date: 'fa fa-calendar',
                    up: 'fa fa-chevron-up',
                    down: 'fa fa-chevron-down'
                },
            };
        },
        reset: function() {
            this.summary = "";
            this.env = "";
            this.company = [];
            this.order_cnt = 0;
            this.returned_product_count = 0;
            this.sales_total = 0;
            this.sales_orders = [];
            this.sales_taxes = [];
            this.max_sales_hour = '';
            this.sales_journal = [];
            this.sales_cashbox = [];
            this.sales_total = "";
            this.sales_users = [];
            this.sales_category = [];
            this.refunds = [];
        },
        show: function() {
            this._super();
            this.set_mode('session');
        },
        print_sales_overview : function() {
            var self = this;
            return this.set_mode('session');
        },
        set_mode: function(mode) {
            var self = this;
            this.mode = mode;
            this.$("select[name=mode]").val(mode);
            if(mode === "session") {
                self.$('.textinputbox, .button-panel').hide();
                $('.overview-week, .overview-day').removeClass('selected');
                self.pos_config_id = -1;
                self.pos_session_id = self.pos.pos_session.id;
                self.date_from = self.beginning_of_time;
                self.date_to = self.end_of_time;
                return self.fetch_orders();
            }
            else if(mode === "time-range") {
                self.$('.textinputbox, .button-panel').show();

                self.date_from = self.$("#date-from").val();
                self.date_to = self.$("#date-to").val();
                self.pos_config_id = self.pos.config.id;
                self.pos_session_id = -1;

                return self.fetch_orders();
            }
        },        
        renderElement: function() {
            var self = this;
            this._super();

            this.$('#date-from').change(function() {
                self.date_from = $(this).val();
            });
            this.$('#date-to').change(function() {
                self.date_to = $(this).val();
            });

            this.$('#date-from, #date-to').datetimepicker(this.datepicker_options).change(function() {
                $('.overview-week, .overview-day').removeClass('selected');
                self.pos_config_id = self.pos.config.id;
                self.pos_session_id = -1;
                self.fetch_orders();
            });

            this.$("#date-from").val(this.date_from);
            this.$("#date-to").val(this.date_to);
            this.$("select[name=mode]").change(function () {
                self.set_mode(this.value);
            });

  
            this.$('.overview-day').click(function() {

                $('.overview-day').addClass('selected');
                $('.overview-week').removeClass('selected');

                self.date_from = self.today;
                self.date_to = self.today;

                self.$("#date-from").val(self.date_from);
                self.$("#date-to").val(self.date_to);
                self.fetch_orders();
            });

            this.$('.overview-week').click(function() {

                $('.overview-day').removeClass('selected');
                $('.overview-week').addClass('selected');

                self.date_from = self.firstWeekDay;
                self.date_to = self.today;

                self.$("#date-from").val(self.date_from);
                self.$("#date-to").val(self.date_to);
                
                self.fetch_orders();
            });

            this.$('.back').click(function(){
                self.gui.show_screen('products');
            });

            this.$('.button.print').click(function(){
                self.print();
            });
            this.$('.show-orderlist').click(function(){
                self.gui.show_screen('orderlist');
            });

            this.$("#show-products").click(function(){
                if(self.$("#show-products").is(':checked')){
                    self.show_products = true;
                    self.fetch_orders();
                }
                else {
                    self.show_products = false;
                    self.fetch_orders();
                }
            });


        },        
        fetch_orders : function(def) {
            var self = this;

            var cashier = this.pos.get_cashier();
            var showError_Role = function() {
                return self.pos.gui.show_popup('error',
                    {
                        title : _t('Warning'),
                        body : _t('You have no access to open sales overview. Please contact your manager!'),
                        cancel: function() {
                            this.gui.show_screen('products');
                        },
                    }
                );
            }

            if(cashier['role'] != 'manager' && this.pos.config.restricted_rule){
                return showError_Role();
            }

            var session = new Model('pos.session');
            var fetch_def = session.call("fetch_orders", [
                this.pos_session_id,
                this.pos_config_id,
                this.date_from,
                this.date_to
            ], undefined, {timeout : 15000000});

            fetch_def.done(function(result) {
                self.max_sales_hour  = result.max_sales_hour;
                self.sales_total     = result.sales_total;
                self.order_cnt       = result.order_cnt;

                // Sales by Orders
                self.sales_orders = result.sales_orders;
                self.sales_taxes = result.sales_taxes;
                self.sales_journal = result.sales_journal;
                self.sales_users = result.sales_users;
                self.sales_category = result.sales_category;
                self.refunds = result.refunds;
                self.product_count = result.product_count;
                self.returned_product_count = result.returned_product_count;

                self.sales_cashbox = self.pos.config.cash_control ? result.sales_cashbox : [];

                if(!self.show_products){
                    self.sales_orders = []
                }

                self.set_env();  
                $('.sales-overview-screen div.pos-receipt-container').html(
                    QWeb.render('SalesSummaryScreen', self.env)
                );

            }).fail(function () {
                $('.sales-overview-screen div.pos-receipt-container').html(
                    QWeb.render('SalesSummaryError')
                );
            });

            return fetch_def;
        },
        get_separator_line: function(symbol) {
            symbol = symbol || "-";
            return new Array(parseInt(this.pos.config.bill_width)).join(symbol);
        },
        set_env: function() {
            var self = this;
            var bill_width = this.pos.config.bill_width;

            this.sales_orders = this.export_sales_order_print();

            this.env = {
                widget:         this,
                pos:            this.pos,
                bill_width :    bill_width,
                company :       self.export_company_print(),
                timestamp:      moment(new Date()).format('DD.MM.YYYY HH:mm'),
                sep:            self.get_separator_line(),
                decimal_point:  _t.database.parameters.decimal_point,
            };
        },
        get_receipt_for_screen: function() {
            if(this.order_cnt && this.order_cnt > 0) {
                return QWeb.render('SalesSummaryScreen', this.env);
            }
            else {
                return QWeb.render('EmptyScreen');
            }
        },
        get_receipt_for_print: function() {
            if(this.order_cnt && this.order_cnt > 0)
                return QWeb.render('SalesSummaryPrint', this.env);
            else
                return QWeb.render('EmptyPrint');
        },
        print_web: function() {
            window.print();
        },
        print_xml: function() {
            if(this.order_cnt > 0) {
                var xmlReceipt = QWeb.render('SalesSummaryPrint', this.env);
                return this.pos.get_proxy().message('print_xml_receipt',{ receipt: xmlReceipt },{ timeout: 5000000 });
            }
        },
        print: function() {
            var self = this;
            var done = new $.Deferred();
            if (this.pos.config.iface_print_via_proxy) { // proxy (xml) printing
                var printed = this.print_xml();
                if (printed && typeof printed.done !== 'undefined') {
                    return printed;
                }
            } else if(this.gui.get_current_screen() === 'overview') {    // browser (web) printing only on current screen
                self.print_web();
            }
            done.resolve();
            return done;
        },
       
        close: function() {
            this._super();

            this.summary = "";
            this.sales_orders = []; 
            this.sales_taxes = [];
            this.max_sales_hour = '';
            this.sales_journal = [];
            this.sales_cashbox = [];
            this.sales_total = "";
            this.sales_users = [];
            this.sales_category = [];
            
            if(this.pos.config.iface_vkeyboard && this.chrome.widget.keyboard){
                this.chrome.widget.keyboard.hide();
            }
        },

        format_quantity_str_with_unit: function(quantity, uom_id){
            var unit = this.pos.units_by_id[uom_id];
            if (unit && unit.is_unit) {
                return quantity.toFixed(0) + ' x ';
            } else {
                return quantity.toFixed(this.pos.dp['Product Unit of Measure']) + ' ' + unit.name + ' x ';
            }
        },
        wrap_line: function(line, length, ratio) {
            if (length <= 1) {
                ratio = length;
                length = undefined;
            }
            length = length || this.pos.config.bill_width || 40;
            ratio = ratio || 0.6;
            var MAX_LENGTH = Math.floor(length * ratio);
            var wrapped = [];
            var name = line || '';
            var current_line = "";

            while (name.length > 0) {
                var space_index = name.indexOf(" ");

                if (space_index === -1) {
                    space_index = name.length;
                }

                if (current_line.length + space_index > MAX_LENGTH) {
                    if (current_line.length) {
                        wrapped.push(current_line);
                    }
                    current_line = "";
                }

                current_line += name.slice(0, space_index + 1);
                name = name.slice(space_index + 1);
            }

            if (current_line.length) {
                wrapped.push(current_line);
            }

            return wrapped;
        },

        export_sales_order_print: function() {
            var self = this;
            var pos = this.pos;
            // This should be maximal length of the right column
            var total_width = self.format_currency(this.sales_total).length;
            return this.sales_orders.map(function (order) {
                var quantity_with_unit = self.format_quantity_str_with_unit(order.amount, order.uom_id);
                var width = pos.config.bill_width - quantity_with_unit.length - total_width;
                return Object.assign(order, {
                    quantity_with_unit: quantity_with_unit,
                    name_wrapped: self.wrap_line(order.name +
                        (order.variant_name ? '('.concat(order.variant_name, ')') : ''), width, 0.8)
                })
            });
        },
        export_company_print: function() {

            var maxwidth = this.pos.config.bill_width;
            var company = this.pos.company;

            /*
             * The company object is displayed in the header of the receipt. For some reason, 
             * sometimes the company name is set in the field contact_address. 
             * Therefor we either display one or the other.
             *
             * As the font is double size, maxwidth will be divided by 2
             */
            if (company.name && typeof company.name === 'string') {
                company.name = company.name.wordWrap((maxwidth / 2), "\n", true).split("\n");
            }
            else if (company.contact_address && typeof company.contact_address === 'string') {
                company.contact_address = company.contact_address.wordWrap( (maxwidth / 2) , "\n", true).split("\n"); //double width
            }
            
            company.address_str = [];

            if (company.street && company.zip && company.city) {

                var _address_str = company.street + ", " + company.zip + " " + company.city;

                if (_address_str.length > maxwidth) {
                    var arr = company.street.wordWrap(maxwidth, "\n", true).split("\n");
                    arr[arr.length] = company.zip + " " + company.city;
                    company.address_str = arr;
                } else {
                    company.address_str[0] = _address_str;
                }
            }

            return company;
        },
    });
    gui.define_screen({name:'overview', widget:OverviewScreenWidget});
    
    /*
     * Show the sales summary in a new screen
     */
    var SalesOverviewButton = screens.ActionButtonWidget.extend({
        template: 'SalesOverviewButton',
        button_click: function() {
            this.gui.show_screen('overview');
        }
    });
    screens.define_action_button({
        'name': 'sales-overview',
        'widget': SalesOverviewButton,
        condition : function() {
            return (this.pos.user.role === 'manager');
        }
    });


    /*
    * Order List
    */
    var PosModelSuper = models.PosModel.prototype;
    models.PosModel = models.PosModel.extend({
        push_order: function(order, opts) {
            if (order) {
                this.all_orders.unshift({
                    uid: order.uid,
                    name: order.name,
                    formatted_date: moment(order.creation_date).format('YYYY-MM-DD HH:mm:ss'),
                    amount_total: order.get_total_with_tax(),
                    serialized: JSON.stringify(order.export_as_JSON())
                });
            }
            return PosModelSuper.push_order.call(this, order, opts);
        },
        map_fields: function(orders) {
            return orders.map(function (order) {
                return Object.assign(order, {
                    uid: order.pos_reference.substr(-14),
                    name: order.pos_reference,
                    formatted_date: order.date_order
                })
            })
        }
    });

    models.load_models([{
        model:  'pos.order',
        fields: ['amount_total', 'pos_reference', 'date_order', 'create_date', 'serialized'],
        domain: function(self){ return [
            ['session_id','=', self.pos_session.id],
        ]; },
        loaded: function(self, orders){
            self.all_orders = self.map_fields(orders);
        },
    }]);

    models.Order = models.Order.extend({
        export_for_reprinting: function() {
            var receipt = this.export_for_printing();
            var date = moment(this.validation_date).toDate();
            receipt.date = {
                year: date.getFullYear(),
                month: date.getMonth(),
                date: date.getDate(),
                day: date.getDay(),
                hour: date.getHours(),
                minute: date.getMinutes(),
                isostring: date.toISOString(),
                localestring: moment(this.validation_date).format('l LT')
            };
            return receipt;
        }
    });

    models.Paymentline = models.Paymentline.extend({
        /*
         * cashregisters_by_id keeps banks statements for current open session only
         * If we reprint an order from past session, this.pos.cashregisters_by_id[json.statement_id] will fail
         */
        init_from_JSON: function(json){
            this.amount = json.amount;
            this.cashregister = this.pos.cashregisters_by_id[json.statement_id];
            if (this.cashregister && this.cashregister.journal_id) {
                this.name = this.cashregister.journal_id[1];
            } else { // Restore from json
                this.name = json.name;
                this.cashregister = {
                    id: json.statement_id,
                    name: json.name,
                    account_id: json.account_id,
                    journal_id: json.journal_id
                };
            }
        },
    });

    var OrderListScreenWidget = screens.ScreenWidget.extend({
        template:'OrderListScreenWidget',
        init: function(parent, options){
            this._super(parent, options);
            this.pos.db.inactive_products = [];
        },
        show: function(){
            var self = this;
            this._super();

            this.renderElement();

            this.$('.back').click(function(){
                self.gui.back();
            });

            this.$('.order-list-content').delegate('.print', 'click', function(event){
                self.call_print($(this).data('id'));
            });

            this.$('.order-list-content').delegate('.print_enhanced', 'click', function(event){
                self.call_print($(this).data('id'), true);
            });

            //descending sort by uid
            this.pos.all_orders.sort(function(a, b){
                return b.uid.localeCompare(a.uid);
            });

            this.render_list();

        },
        render_list: function(orders){
            orders = orders || this.pos.all_orders;
            var contents = this.$el[0].querySelector('.order-list-content');
            contents.innerHTML = "";
            for(var i = 0; i < orders.length; i++){
                var orderline_html = QWeb.render('OrderLine',{widget: this, order:orders[i]});
                var orderline = document.createElement('tbody');
                orderline.innerHTML = orderline_html;
                orderline = orderline.childNodes[1];

                contents.appendChild(orderline);
            }
        },
        find_by_uid: function(uid) {
            return this.pos.all_orders.filter(function(item) {
                return item.uid === uid;
            }).shift();
        },
        call_print: function(uid, enhanced_receipt){
            var self = this;
            enhanced_receipt = enhanced_receipt || false;
            var order = this.find_by_uid(uid);
            if (order) {

                var data = JSON.parse(order.serialized);

                // Load in unloaded products
                var unloaded = _(data.lines)
                    .filter(function (item) { return !(item[2].product_id in self.pos.db.product_by_id); })
                    .map(function(item) { return item[2].product_id });

                var records;

                if (unloaded.length > 0) {
                    // Find product model and load more stuff
                    for (var i = 0; i < self.pos.models.length; i++) {
                        var currentModel = self.pos.models[i];
                        if (currentModel.model === 'product.product') {
                            var tmp = {};
                            var fields =  typeof currentModel.fields === 'function'  ? currentModel.fields(self.pos,tmp)  : currentModel.fields;
                            var context = typeof currentModel.context === 'function' ? currentModel.context(self.pos,tmp) : currentModel.context;
                            records = new Model(currentModel.model).call('read',[unloaded,fields]);

                            records.then(function(result){
                                self.inactive_products = result;
                                try{    // catching exceptions in model.loaded(...)
                                    $.when(currentModel.loaded(self.pos,result,tmp))
                                       .always(function(){
                                           self.pos.order_to_reprint = new models.Order({}, {
                                                pos: self.pos,
                                                json: data,
                                                reprint: true,
                                                create_date: order.create_date,
                                                date_order: order.date_order
                                            });
                                           self.pos.order_to_reprint.enhanced_receipt = enhanced_receipt;
                                           self.pos.gui.show_screen('reprint-receipt'); })
                                    //currentModel.loaded(self,result,tmp)
                                } catch(err) {
                                    console.error(err.message, err.stack);
                                }
                            });

                            self.pos.models[i] = currentModel;
                            break;
                        }
                    }
                } else {
                    this.pos.order_to_reprint = new models.Order({}, {
                        pos: this.pos,
                        json: JSON.parse(order.serialized),
                        reprint: true,
                        create_date: order.create_date,
                        date_order: order.date_order
                    });
                    this.pos.order_to_reprint.enhanced_receipt = enhanced_receipt;
                    this.pos.gui.show_screen('reprint-receipt');
                }
            }
        },
    });
    gui.define_screen({name:'orderlist', widget:OrderListScreenWidget});

    var OrderListButton = screens.ActionButtonWidget.extend({
        template: 'OrderListButton',
        button_click: function() {
            this.gui.show_screen('orderlist');
        }
    });
    screens.define_action_button({
        'name': 'sales-orderlist',
        'widget': OrderListButton,
        condition : function() {
            return (this.pos.user.role === 'manager');
        }
    });

    /*
     * Reprint receipt
     */
    var ReprintReceiptScreenWidget = screens.ReceiptScreenWidget.extend({
        template: 'ReprintReceiptScreenWidget',
        click_back: function() {
            this.gui.show_screen('products');
        },
        should_auto_print: function() {
            return this.pos.config.iface_print_auto;
        },
        print_web: function() {
            window.print();
        },
        print_xml: function() {
            var order = this.pos.order_to_reprint;
            if (order) {

                var env = {
                    widget:  this,
                    pos: this.pos,
                    order: order,
                    receipt: order.export_for_reprinting(),
                    paymentlines: this.pos.order_to_reprint.get_paymentlines()
                };
                var receipt = QWeb.render('XmlReceipt',env);

                this.pos.get_proxy().print_receipt(receipt);
                this.pos.order_to_reprint.destroy();
            }
        },
        click_next: function() {},
        render_change: function() {},
        render_receipt: function() {
            var order = this.pos.order_to_reprint;
            if (order) {
                this.$('.pos-receipt-container').html(QWeb.render('PosTicket',{
                        widget:this,
                        order: order,
                        receipt: order.export_for_reprinting(),
                        orderlines: order.get_orderlines(),
                        paymentlines: order.get_paymentlines(),
                }));
                this.pos.order_to_reprint.destroy();
            }
        },
        close: function(){
            this._super();

            var products = this.pos.db.inactive_products;
            if(products.length > 0) {
                var stored_categories = this.pos.db.product_by_category_id;
                for(var i = 0, len = products.length; i < len; i++) {
                    var product = products[i];
                    var categ_id = product.pos_categ_id ? product.pos_categ_id[0] : this.pos.db.root_category_id;
                    product.product_tmpl_id = product.product_tmpl_id[0];

                    var index = stored_categories[categ_id].indexOf(product.id);
                    if (index > -1) {
                        stored_categories[categ_id].splice(index, 1);
                    }

                    var ancestors = this.pos.db.get_category_ancestors_ids(categ_id) || [];

                    for(var j = 0, jlen = ancestors.length; j < jlen; j++){
                        var ancestor = ancestors[j];

                        index = stored_categories[ancestor].indexOf(product.id);
                        if (index > -1) {
                            stored_categories[ancestor].splice(index, 1);
                        }
                    }
                    index = this.pos.db.product_by_id.indexOf(product.id);
                    if (index > -1) {
                        this.pos.db.product_by_id.splice(index, 1);
                    }
                    if(product.barcode){
                        index = this.pos.db.product_by_barcode.indexOf(product.id);
                        if (index > -1) {
                            this.pos.db.product_by_barcode.splice(index, 1);
                        }
                    }
                }
                this.pos.db.inactive_products = [];
            }
        },
    });
    gui.define_screen({name:'reprint-receipt', widget: ReprintReceiptScreenWidget});

    /*
    * Print overview when exiting
    * */
    gui.Gui.include({
        close: function() {
            var self = this;
            var _super = this._super
            // This can be called even before models are loaded
            if (this.pos && this.pos.config && this.pos.config.iface_print_summary) {
                var overviewScreen = this.screen_instances['overview'];
                if (overviewScreen) {
                    overviewScreen.print_sales_overview().then(function () {
                        overviewScreen.print();
                    }).then(function () {
                        _super.apply(self, arguments);
                    });
                } else {
                    _super.apply(this, arguments);
                }
            } else {
                _super.apply(this, arguments);
            }
        }
    });

    /*
    * Override print_sale_details button
    * */
    devices.ProxyDevice.include({
        print_sale_details: function() {
            var self = this;
            var overviewScreen = this.pos.gui.screen_instances['overview'];
            if (overviewScreen) {
                overviewScreen.print_sales_overview().done(function () {
                    overviewScreen.print();
                });
            }
        },
    });

    return {
        OverviewScreenWidget: OverviewScreenWidget,
        OrderListScreenWidget: OrderListScreenWidget,
        ReprintReceiptScreenWidget: ReprintReceiptScreenWidget
    }
});
