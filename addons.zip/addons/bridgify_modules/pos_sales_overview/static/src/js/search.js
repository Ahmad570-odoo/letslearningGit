odoo.define('bridgify.search', function (require) {
"use strict";

    var Model = require('web.DataModel');
    var framework = require('web.framework');
    var overview = require('bridgify.pos_overview');
    var models = require('point_of_sale.models');
    var gui = require('point_of_sale.gui');
    var core = require('web.core');
    var _t   = core._t;

    overview.OrderListScreenWidget.include({
        init: function(parent, options){
            var self = this;
            this._super(parent,options);
            this.pos.search_results = [];
            this.search_handler = function(event){
                var search_timeout  = null;
                if(event.type === "keypress" || event.keyCode === 46 || event.keyCode === 8){
                    clearTimeout(search_timeout);

                    var searchbox = this;

                    search_timeout = setTimeout(function(){
                        self.perform_search(searchbox.value, event.which === 13);
                    }, 400);
                }
            };
        },
        show: function(){
            var self = this;
            this._super();

            if(this.pos.config.iface_vkeyboard && this.chrome.widget.keyboard){
                this.chrome.widget.keyboard.connect(this.$('.searchbox input'));
            }

            this.$('.searchbox input').keypress(this.search_handler);
            this.$('.searchbox input').keydown(this.search_handler);

            this.$('.searchbox .search-clear').click(function(){
                self.clear_search();
            });
        },
        perform_search: function(query) {
            var orders;
            var self = this;
            if (query) {
                // Local search
                orders = this.pos.all_orders.filter(function (order) {
                    return order.name.search(query) >= 0;
                });
                // Remote search
                if (orders.length === 0) {
                    framework.blockUI();
                    new Model('pos.order').call('search_read', [[['pos_reference', 'like', query]],
                        ['amount_total', 'pos_reference', 'date_order', 'create_date', 'serialized']], {limit: 10}).then(
                            function (data) {
                                self.pos.search_results = data;
                                self.render_list(self.pos.map_fields(data));
                            }).fail(function (error, event){
                                self.pos.gui.show_popup('error', error);
                            }).always(function() {
                                framework.unblockUI();
                            });
                } else {
                    self.pos.search_results = [];
                }
            }
            this.render_list(orders);
        },
        clear_search: function(){
            this.render_list();
            this.$('.searchbox input')[0].value = '';
            this.$('.searchbox input').focus();
        },
        find_by_uid: function(uid) {
            return this.pos.search_results.concat(this.pos.all_orders).filter(function(item) {
                return item.uid === uid;
            }).shift();
        },
    });

});

