odoo.define('bridgify.refund', function (require) {
"use strict";

    var overview = require('bridgify.pos_overview');
    var screens = require('point_of_sale.screens');
    var models = require('point_of_sale.models');
    var gui = require('point_of_sale.gui');
    var core = require('web.core');
    var _t   = core._t;

    models.load_fields('account.journal', ['allow_refund']);

    models.Paymentline = models.Paymentline.extend({
        same_journal: function (item) {
            var journal_id = Array.isArray(item.journal_id) ? item.journal_id[0] : item.journal_id;
            return this.cashregister.journal.id === journal_id;
        },
        set_max_refund_amount: function (order) {
            // Prevent refunding the amount higher than originally paid
            if (this.cashregister.journal.type === 'bank' && this.cashregister.journal.allow_refund === 'bank') {
                var self = this;
                var max_refund_amount = _(order.refund_statement_ids)
                    .filter(function (item) {return self.same_journal(item);})
                    .map(function (item) {return item.amount;})
                    .reduce(function (sum, item) {return sum + item;}, 0);
                this.set_amount( Math.max(order.get_total_with_tax(), -max_refund_amount) );
            }
        },
    });

    var _super_order = models.Order.prototype;
    models.Order = models.Order.extend({
        initialize: function(attr, options) {
            _super_order.initialize.apply(this, arguments);
            this.refund = this.refund || false;
            this.refund_statement_ids = this.refund_statement_ids || [];
        },
        add_paymentline: function(cashregister) {
            _super_order.add_paymentline.apply(this, arguments);
            if(this.refund){
                this.selected_paymentline.set_max_refund_amount(this);
            }
        },
        export_as_JSON: function(){
            var json = _super_order.export_as_JSON.call(this);
            json.refund = this.refund;
            json.refund_statement_ids = this.refund_statement_ids;
            return json;
        },
        init_from_JSON: function(json){
            _super_order.init_from_JSON.apply(this,arguments);
            this.refund = json.refund;
            this.refund_statement_ids = json.refund_statement_ids;
            this.name = (this.refund ? _t('Refund ') : _t('Order ')) + this.uid;
        },
        export_for_printing: function() {
            var receipt = _super_order.export_for_printing.call(this);
            receipt.refund = this.refund;
            if (this.refund) {
                receipt.title = _t('Refund');
            };
            return receipt;
        }
    });

    overview.OrderListScreenWidget.include({
        show: function() {
            var self = this;
            this._super();
            this.$('.order-list-content').delegate('.refund', 'click', function(event){
                self.call_refund($(this).data('id'));
            });
        },
        call_refund: function(uid){
            var self = this,
                pos = this.pos,
                order = this.find_by_uid(uid),
                json = JSON.parse(order.serialized);
            // Disable refund for certain payment methods:
            var disable_refund = _(json.statement_ids).map(function (line) {
                return new models.Paymentline({}, {pos: pos, json: line[2]});
            }).filter(function (line) {
                return (line.cashregister && line.cashregister.journal && line.cashregister.journal.allow_refund === 'disable');
            });
            _(disable_refund).each(function (line) {
                self.gui.show_popup('error', {
                    'title': _t('Error'),
                    'body': _t('This order was paid with') + ' ' + line.name + ' ' +
                            _t('payment method, that is set to Disallow refunds.\n\n Please contact your manager!'),
                });
            });

            if (disable_refund.length === 0) {
                this.gui.show_popup('refund', {
                    title: _t('Refund ') + order.name + '?',
                    order: order,
                    confirm: function(note) {
                        self.create_refund(json, note);
                    }
                });
            }
        },
        create_refund: function(json, note) {
            var pos = this.pos;
            var order = pos.get_order();
            var refund = order.is_empty() ? order : pos.add_new_order();
            refund.refund = true;
            refund.note = _t('Refund for: ') + json.name + "\n\n" + note;
            refund.name = _t('Refund ') + refund.uid;
            refund.refund_statement_ids = _(json.statement_ids).map(function (item) {
                return item.slice(-1)[0]
            });
            json.lines.forEach(function (json_line) {
                var line = new models.Orderline({}, {pos: pos, order: refund, json: json_line[2]});
                line.set_quantity(-line.quantity);
                refund.add_orderline(line);
            });
            pos.gui.show_screen('products');
        }
    });

    var TextAreaPopup = gui.Gui.prototype.popup_classes.find(function (popup) {
       return popup.name === 'textarea';
    });
    var RefundPopupWidget = TextAreaPopup.widget.extend({
        click_confirm: function(){
            if (this.$('textarea').val().trim())
                this._super();
            this.$('textarea').focus();
            this.$('textarea').css({boxShadow: '0 0 0 2px red' });
        },
        show: function(options){
            this._super(options);
            this.$('textarea').attr('required', true);
            this.$('textarea').attr('placeholder', _t('Enter refund note...'));
        },
    });
    gui.define_popup({name:'refund', widget: RefundPopupWidget});
    
    screens.PaymentScreenWidget.include({
        show: function(){
            this._super();
            this.$('.paymentmethods-container').html(this.render_paymentmethods());
        },
        order_is_valid: function(force_validation) {
            var self = this;
            var order = this.pos.get_order();

            // FIXME: this check is there because the backend is unable to
            // process empty orders. This is not the right place to fix it.
            if (order.get_orderlines().length === 0) {
                this.gui.show_popup('error',{
                    title: _t('Empty Order'),
                    body:  _t('There must be at least one product in your order before it can be validated'),
                });
                return false;
            }

            var plines = order.get_paymentlines();

            // in case of refund plines is empty but order can be verified. TODO find why refund can be verified without payment method
            if (plines.length === 0){
                this.gui.show_popup('error',{
                        title: _t('Select Payment Method'),
                        body: _t('You cannot validate an order without payment method.'),
                    });
                    return false;
            }

            for (var i = 0; i < plines.length; i++) {
                // 20180619 VT: allow refunds
                var cashregister = plines[i].cashregister;
                if (order.refund && plines[i].get_type() === 'bank' && cashregister.journal.allow_refund === 'bank') {
                    continue;
                }
                // end of mod
                if (plines[i].get_type() === 'bank' && plines[i].get_amount() < 0) {
                    this.gui.show_popup('error',{
                        title: _t('Negative Bank Payment'),
                        body: _t('You cannot have a negative amount in a Bank payment. Use a cash payment method to return money to the customer.'),
                    });
                    return false;
                }
            }

            if (!order.is_paid() || this.invoicing) {
                return false;
            }

            // The exact amount must be paid if there is no cash payment method defined.
            if (Math.abs(order.get_total_with_tax() - order.get_total_paid()) > 0.00001) {
                var cash = false;
                for (var i = 0; i < this.pos.cashregisters.length; i++) {
                    cash = cash || (this.pos.cashregisters[i].journal.type === 'cash');
                }
                if (!cash) {
                    this.gui.show_popup('error',{
                        title: _t('Cannot return change without a cash payment method'),
                        body:  _t('There is no cash payment method available in this point of sale to handle the change.\n\n Please pay the exact amount or add a cash payment method in the point of sale configuration'),
                    });
                    return false;
                }
            }

            // if the change is too large, it's probably an input error, make the user confirm.
            if (!force_validation && order.get_total_with_tax() > 0 && (order.get_total_with_tax() * 1000 < order.get_total_paid())) {
                this.gui.show_popup('confirm',{
                    title: _t('Please Confirm Large Amount'),
                    body:  _t('Are you sure that the customer wants to  pay') +
                           ' ' +
                           this.format_currency(order.get_total_paid()) +
                           ' ' +
                           _t('for an order of') +
                           ' ' +
                           this.format_currency(order.get_total_with_tax()) +
                           ' ' +
                           _t('? Clicking "Confirm" will validate the payment.'),
                    confirm: function() {
                        self.validate_order('confirm');
                    },
                });
                return false;
            }

            return true;
        },

    });

});

