# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging
from odoo import api, fields, models, _
from datetime import timedelta
from pytz import timezone
from dateutil.parser import parse
from odoo.exceptions import Warning

_logger = logging.getLogger(__name__)


class PosDetails(models.TransientModel):
    _inherit = 'pos.details.wizard'

    @api.multi
    def generate_sales_overview_report(self):
        if not self._context.get('tz'):
            raise Warning(_("The user who prints the sales overview report has no timezone! Please add the timezone!"))
        data = {'date_start': self.start_date, 'date_stop': self.end_date, 'config_ids': self.pos_config_ids.ids}
        return self.env['report'].get_action(
            [], 'pos_sales_overview.report_saleoverview', data=data)


class ReportSaleOverview(models.AbstractModel):
    _name = 'report.pos_sales_overview.report_saleoverview'

    @api.model
    def get_sale_overview(self, date_start=False, date_stop=False, configs=False):
        datas = {}
        local_timezone = timezone(self._context.get('tz'))
        utc = timezone('UTC')

        _logger.info("Start: %s, stop: %s" % (date_start, date_stop))

        date_start2 = utc.localize(parse(date_start))
        date_stop2 = utc.localize(parse(date_stop))

        _logger.info("Start: %s, stop: %s" % (date_start2, date_stop2))

        date_start2 = date_start2.astimezone(local_timezone)
        date_stop2 = date_stop2.astimezone(utc)

        _logger.info("Start: %s, stop: %s" % (date_start2, date_stop2))

        date_start2 = date_start2.strftime("%d-%m-%Y")
        date_stop2 = date_stop2.strftime("%d-%m-%Y")

        _logger.info("Start: %s, stop: %s" % (date_start2, date_stop2))
        if configs:
            # session id has to be -1 because we do not print it out from POS
            data = self.env['pos.session'].fetch_orders(-1, configs.ids, date_start2, date_stop2)
            data['date_start'] = date_start
            data['date_stop'] = date_stop
            data['user_name'] = self.env.user.name
            data['currency'] = self.env.user.company_id.currency_id
            data['company_name'] = self.env.user.company_id.name
            return data
        else:
            return False

    @api.multi
    def render_html(self, docids, data=None):
        data = dict(data or {})
        configs = self.env['pos.config'].browse(data['config_ids'])
        data_update = self.get_sale_overview(data['date_start'], data['date_stop'], configs)
        if data_update:
            data.update(data_update)
            return self.env['report'].render('pos_sales_overview.report_saleoverview', data)
