# -*- coding: utf-8 -*-
from . import pos_multi_session_menu_model
