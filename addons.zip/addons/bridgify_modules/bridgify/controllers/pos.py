# -*- coding: utf-8 -*-
import json
import logging
import werkzeug.utils
from odoo import http, _
from odoo.http import request
import odoo.addons.point_of_sale
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class Main(odoo.addons.point_of_sale.controllers.main.PosController):

    def _check_session(self, pos_config):
        pos_session = request.env['pos.session']
        res = not pos_session.search_count([
            ('state', 'not in', ('closed', 'closing_control')),
            ('user_id', '=', request.session.uid),
            ('name', 'not like', 'RESCUE FOR'),
        ]) and not pos_session.search_count([
            ('state', '!=', 'closed'),
            ('config_id', '=', pos_config.id),
            ('name', 'not like', 'RESCUE FOR'),
        ])
        return res

    def logout(self, error):
        values = request.params.copy()
        values['error'] = error
        return request.render('web.login', values)

    @http.route('/pos/web', type='http', auth='user')
    def pos_web(self, debug=False, **k):
        """ Connect to existing session or automatically start a new one
        """
        pos_sessions = request.env['pos.session'].search([
            ('state', '=', 'opened'),
            ('user_id', '=', request.session.uid),
            ('name', 'not like', '(RESCUE FOR')
        ])

        if not pos_sessions:
            pos_config = request.env['pos.config'].search([], limit=1)
            if request.env.user.pos_restricted and request.env.user.pos_config:
                pos_config = request.env.user.pos_config

            if not pos_config:
                return self.logout(_('No POS found')) if request.env.user.pos_restricted \
                    else werkzeug.utils.redirect('/web#action=point_of_sale.action_client_pos_menu')

            # If user is restricted to POS front-end we have to check the constraints in advance
            if request.env.user.pos_restricted:
                # TODO: login session even if cash control activated
                if not self._check_session(pos_config) or pos_config.cash_control:
                    return self.logout(_('Cannot login to POS: either the session is occupied by another user or '
                                         ' cash control is activated and you''re not authorized to open new session'))

            pos_sessions = request.env['pos.session'].create({
                'user_id': request.session.uid,
                'config_id': pos_config.id
            })

            # Session is not opened by default when created in point_of_sale.pos_session model
            if pos_config.cash_control:
                pos_sessions.action_pos_session_open()
        # FIX: https://github.com/odoo/odoo/pull/24486
        context = {
            'session_info': json.dumps(request.env['ir.http'].session_info()),
            'login_number': pos_sessions.login(),
        }

        return request.render('point_of_sale.index', qcontext=context)
