# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import imghdr
import jinja2
import odoo.tools
import werkzeug.utils
from odoo.http import request
from urlparse import urlparse
from cStringIO import StringIO
from contextlib import closing
from odoo import http, SUPERUSER_ID, _
import odoo.addons.web.controllers.main as main
from odoo.modules import get_resource_path
import json

loader = jinja2.PackageLoader('odoo.addons.bridgify', "views")
env = jinja2.Environment(loader=loader, autoescape=True)


class BridgifyHome(main.Home):

    @http.route('/web', type='http', auth="none")
    def web_client(self, s_action=None, **kw):
        config = odoo.addons.bridgify.config
        main.ensure_db(config and config['base_url'] or None)    # Redirect to connect if no database selected
        if not request.session.uid:
            return werkzeug.utils.redirect('/web/login', 303)
        if kw.get('redirect'):
            return werkzeug.utils.redirect(kw.get('redirect'), 303)

        request.uid = request.session.uid
        context = request.env['ir.http'].webclient_rendering_context()

        if request.env.user and request.env.user.pos_restricted:
            return http.local_redirect('/pos/web')
        return request.render('web.webclient_bootstrap', qcontext=context)

    @http.route('/web/login', type='http', auth="none")
    def web_login(self, redirect=None, **kw):
        config = odoo.addons.bridgify.config
        main.ensure_db(config and config['base_url'] or None)    # Redirect to connect if no database selected
        return super(BridgifyHome, self).web_login(redirect=redirect, **kw)


class BrBinary(main.Binary):
    @http.route(['/web/binary/company_logo', '/logo', '/logo.png'], type='http', auth="none", cors="*")
    def company_logo(self, dbname=None, **kw):
        imgname = 'logo'
        imgext = '.svg'
        uid = None
        if request.session.db:
            dbname = request.session.db
            uid = request.session.uid
        elif dbname is None:
            dbname = http.db_monodb()

        uid = uid or SUPERUSER_ID

        if not dbname:
            return http.send_file(get_resource_path('bridgify', 'static', 'src', 'img', imgname + imgext))
        else:
            try:
                # create an empty registry
                registry = odoo.modules.registry.Registry(dbname)
                with registry.cursor() as cr:
                    company = int(kw['company']) if kw and kw.get('company') else False
                    if company:
                        cr.execute("""SELECT logo_web, write_date
                                        FROM res_company
                                       WHERE id = %s
                                   """, (company,))
                    else:
                        cr.execute("""SELECT c.logo_web, c.write_date
                                        FROM res_users u
                                   LEFT JOIN res_company c
                                          ON c.id = u.company_id
                                       WHERE u.id = %s
                                   """, (uid,))
                    row = cr.fetchone()
                    if row and row[0]:
                        image_base64 = str(row[0]).decode('base64')
                        image_data = StringIO(image_base64)
                        imgext = '.' + (imghdr.what(None, h=image_base64) or 'png')
                        response = http.send_file(image_data, filename=imgname + imgext, mtime=row[1])
                    else:
                        response = http.send_file(get_resource_path('bridgify', 'static', 'src', 'img', imgname + imgext))
            except Exception:
                response = http.send_file(get_resource_path('bridgify', 'static', 'src', 'img', imgname + imgext))

        return response

    @http.route(['/web/static/src/img/logo2.png', '/logo2', '/logo2.png'], type='http', auth="none", cors="*")
    def company_logo2(self, **kw):
        return http.send_file(get_resource_path('bridgify', 'static', 'src', 'img', 'logo2.png'))

    @http.route(['/favicon.ico', '/favicon'], type='http', auth="none", cors="*")
    def favicon(self, **kw):
        return http.send_file(get_resource_path('bridgify', 'static', 'src', 'img', 'favicon.ico'))

    @http.route('/logo.svg', type='http', auth="none", cors="*")
    def company_logo_svg(self, **kw):
        return http.send_file(get_resource_path('bridgify', 'static', 'src', 'img', 'logo.svg'))


#class BrDatabase(main.Database):
#    def _render_template(self, **d):
#        return env.get_template("snap.html").render()
