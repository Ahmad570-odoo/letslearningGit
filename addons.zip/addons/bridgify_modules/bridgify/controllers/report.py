# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from werkzeug import exceptions
from odoo.http import route, request
import odoo.addons.report.controllers.main as report


class BridgifyReport(report.ReportController):

    @route('/receipt/<converter>/<number>', type='http', auth='none', website=True)
    def report(self, converter, number=None, **data):
        """ Check receipt exists and run report
        """
        report = 'bridgify.receipt'
        context = dict(request.env.context)
        report_obj = request.env['report']
        for o in request.env['pos.order'].sudo().search([('pos_reference', 'like', number)]):
            if converter == 'html':
                html = report_obj.sudo().with_context(context).get_html([o.id], report, data=data)
                return request.make_response(html)
            elif converter == 'pdf':
                pdf = report_obj.sudo().with_context(context).get_pdf([o.id], report, data=data)
                pdfhttpheaders = [('Content-Type', 'application/pdf'), ('Content-Length', len(pdf))]
                return request.make_response(pdf, headers=pdfhttpheaders)
            else:
                raise exceptions.HTTPException(description='Converter %s not implemented.' % converter)
        return request.not_found()
