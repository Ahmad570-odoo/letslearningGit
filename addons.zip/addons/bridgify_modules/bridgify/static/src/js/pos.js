/* Copyright 2004-2010 OpenERP SA: License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).
 * Copyright 2017 bridgify GmbH: See LICENSE file for full copyright and licensing details.
 */

odoo.define('bridgify.pos', function (require) {
    "use strict";

    var core = require('web.core');
    var Model = require('web.DataModel');
    var formats = require('web.formats');
    var session = require('web.session');
    var gui = require('point_of_sale.gui');
    var PosDB = require('point_of_sale.DB');
    var chrome = require('point_of_sale.chrome');
    var models = require('point_of_sale.models');
    var screens = require('point_of_sale.screens');
    var devices = require('point_of_sale.devices');
    var utils = require('web.utils');

    var round_pr = utils.round_precision;
    var _t = core._t;
    var QWeb = core.qweb;

    models.load_fields('account.tax', ['description', 'code']);
    models.load_fields('res.company', [
        'display_logo', 'display_address', 'display_email', 'display_website', 'display_phone', 'display_tax_code', 'receipt_address_location', 'big_header_text'
    ]);

    models.load_fields('res.partner', ['ref']);

    // TODO refactor extend to include where needed, require hierarchy, remove copy paste functions (wrap_line, get_separator_line)
    // var user_model = models.PosModel.prototype.models.find(function (model) {
    //    return (model.model === 'res.users' && _.isEqual(model.fields, ['name','pos_security_pin','groups_id','barcode']));
    // });
    // var super_loaded = user_model.loaded;
    // user_model.loaded = function(self, users) {
    //     var result = super_loaded(self, users);
    //     self.users = self.users.filter(function (user) {
    //         return self.user.id === 1 || user.id !== 1;
    //     });
    //     return result;
    // };

    // FIX: https://github.com/odoo/odoo/pull/24486
    var session_model = models.PosModel.prototype.models.find(function (model) {
        return (model.model === 'pos.session');
    });
    session_model.fields = session_model.fields.filter(function (value, index, arr) {
        return value !== 'login_number';
    });
    var session_super_loaded = session_model.loaded;
    session_model.loaded = function (self, pos_sessions) {
        session_super_loaded(self, pos_sessions);
        self.pos_session.login_number = odoo.login_number;
    };

    models.load_fields('res.users', ['pos_restricted']);

    PosDB.include({
        // Change partner.address to readable format
        add_partners: function (partners) {
            var self = this;
            var updated_count = this._super(partners);

            if (partners.length) {
                partners.forEach(function (partner) {
                    var address = [], zipcity = [];
                    var rec = self.partner_by_id[partner.id];
                    if (rec.zip) zipcity.push(rec.zip);
                    if (rec.city) zipcity.push(rec.city);
                    if (zipcity.length > 0) address.push(zipcity.join(' '));
                    if (rec.country_id) address.push(rec.country_id[1]);
                    rec.street2 = address.join(', ') || '';
                    if (rec.street) address.unshift(rec.street);
                    rec.address = address.join(', ') || '';
                    rec.ref = rec.ref || '';
                });
            }

            return updated_count;
        },
    });

    var OrderSuper = models.Order.prototype;
    models.Order = models.Order.extend({
        get_separator_line: function (symbol) {
            symbol = symbol || "-";
            return new Array(parseInt(this.pos.config.bill_width)).join(symbol);
        },
        export_for_printing: function () {
            var date = moment();
            var self = this;
            var company = this.pos.company;
            var client = this.get('client');
            var receipt = OrderSuper.export_for_printing.call(this);
            receipt = $.extend(true, receipt, {
                title: _t('Your Purchase'),
                pos_id: this.pos.config.name + '/' + this.pos.config.id,
                client: client,
                bill_width: this.pos.get_max_width(),
                date: {
                    localestring: date.format('l LT')
                },
                company: {
                    display_logo: company.display_logo,
                    display_email: company.display_email,
                    display_website: company.display_website,
                    display_phone: company.display_phone,
                    display_tax_code: company.display_tax_code,
                    contact_address: company.display_address,
                    big_header_text: company.big_header_text,
                    receipt_address_location: company.receipt_address_location
                },
                separator: self.get_separator_line()
            });
            return receipt;
        },
        get_tax_details: function () {
            var self = this;
            var taxes = OrderSuper.get_tax_details.call(this);
            taxes.forEach(function (item) {
                item.total_with_tax = self.get_total_for_taxes(item.tax.id);
                item.name = self.pos.taxes_by_id[item.tax.id].description;
                item.code = self.pos.taxes_by_id[item.tax.id].code;
            });
            return taxes;
        }
    });

    var OrderLineSuper = models.Orderline.prototype;
    models.Orderline = models.Orderline.extend({

        compute_all: function (taxes, price_unit, quantity, currency_rounding, no_map_tax) {
            var self = this;
            var list_taxes = [];
            var currency_rounding_bak = currency_rounding;
            if (this.pos.company.tax_calculation_rounding_method == "round_globally") {
                currency_rounding = currency_rounding * 0.00001;
            }
            var total_excluded = round_pr(price_unit * quantity, currency_rounding);
            var total_included = total_excluded;
            var base = total_excluded;
            console.log(taxes)
            _(taxes).each(function (tax) {
                if (!no_map_tax) {
                    tax = self._map_tax_fiscal_position(tax);
                }
                if (!tax) {
                    return;
                }
                if (tax.amount_type === 'group') {
                    var ret = self.compute_all(tax.children_tax_ids, price_unit, quantity, currency_rounding);
                    total_excluded = ret.total_excluded;
                    base = ret.total_excluded;
                    total_included = ret.total_included;
                    list_taxes = list_taxes.concat(ret.taxes);
                } else {
                    var tax_amount = self._compute_all(tax, base, quantity);
                    tax_amount = round_pr(tax_amount, currency_rounding);
                    // if (tax_amount) {
                    if (tax.price_include) {
                        total_excluded -= tax_amount;
                        base -= tax_amount;
                    } else {
                        total_included += tax_amount;
                    }
                    if (tax.include_base_amount) {
                        base += tax_amount;
                    }
                    var data = {
                        id: tax.id,
                        amount: tax_amount,
                        name: tax.name,
                    };
                    list_taxes.push(data);
                    // }
                }
            });
            return {
                taxes: list_taxes,
                total_excluded: round_pr(total_excluded, currency_rounding_bak),
                total_included: round_pr(total_included, currency_rounding_bak)
            };
        },

        get_quantity_str: function () {
            var unit = this.get_unit();
            if (unit && !unit.is_unit) {
                return this.quantityStr;
            } else {
                if (unit.rounding === 1)
                    return formats.format_value(this.quantity, {type: 'float', digits: [69, 0]});
                return this.quantityStr;
            }
        },
        get_quantity_str_with_unit: function () {
            var unit = this.get_unit();
            if (unit && !unit.is_unit) {
                return this.quantityStr + ' ' + unit.name + ' x ';
            } else {
                if (unit.rounding === 1)
                    return formats.format_value(this.quantity, {type: 'float', digits: [69, 0]}) + ' x ';
                return this.quantityStr + ' x ';
            }
        },

        wrap_line: function (line, length, ratio) {
            if (length <= 1) {
                ratio = length;
                length = undefined;
            }
            length = length || this.pos.config.bill_width || 40;
            ratio = ratio || 0.6;
            var MAX_LENGTH = Math.floor(length * ratio);
            var wrapped = [];
            var name = line || '';
            var current_line = "";

            while (name.length > 0) {
                var space_index = name.indexOf(" ");

                if (space_index === -1) {
                    space_index = name.length;
                }

                if (current_line.length + space_index > MAX_LENGTH) {
                    if (current_line.length) {
                        wrapped.push(current_line);
                    }
                    current_line = "";
                }

                current_line += name.slice(0, space_index + 1);
                name = name.slice(space_index + 1);
            }

            if (current_line.length) {
                wrapped.push(current_line);
            }

            return wrapped;
        },
        export_for_printing: function () {
            var self = this;
            var line = OrderLineSuper.export_for_printing.call(this);
            return Object.assign(line, {
                product_name_quantity: self.wrap_line(this.get_quantity_str_with_unit() + this.get_product().display_name),
                quantity_str: this.get_quantity_str_with_unit(),
                tax_codes: this.get_tax_codes(),
                is_unit: this.get_unit() && this.get_unit().is_unit
            })
        },
        get_tax_codes: function () {
            return this.get_taxes().map(function (tax) {
                if (tax.code) return tax.code;
            }).join(',');
        },
    });

    screens.ReceiptScreenWidget.include({
        hide: function () {
            this.$('.button.email, .button.pdf')
                .toggleClass('disabled', true)
                .off('click');
            this._super();
        },
        setButtons: function (ids) {
            var self = this;
            this.$('.button.email').click(function () {
                if (!self._locked) {
                    self.email(ids);
                }
            });
            this.$('.button.pdf').click(function () {
                $(this).attr('href', '/receipt/pdf/' + self.pos.get_order().uid);
            });
            this.$('.button.email, .button.pdf').toggleClass('disabled', false)
        },
        email: function (ids) {
            var self = this;
            var def = new $.Deferred();

            var client = this.pos.get_order().get_client();
            this.gui.show_popup('textinput', {
                'title': _t('Enter email address'),
                'value': client ? client.email : '',
                confirm: function (email) {
                    def.resolve(email);
                },
                cancel: function () {
                    def.reject();
                }
            });

            return def.then(function (email) {
                return new Model('pos.order').call("send_by_email", [ids, email]).fail(function (error) {
                    self.gui.show_popup('alert', {
                        'title': _t('Error sending message'),
                        'body': error.data ? error.data.message : 'Unknown exception occurred'
                    });
                });
            });
        },
        tax_header_padding: function(taxes) {
            var self = this;

            var t_net = _t("Net");
            var t_total = _t("Total");
            var t_vat = _t("VAT");

            var right = t_net + " " + t_vat + " " + t_total;
            if (taxes.length > 0) {
                // The headers for tax amounts will be padded by their respective lengths
                var net_len = Math.max.apply(Math, taxes.map(function(tax) { return self.format_currency(tax.total_with_tax - tax.amount).length; }));
                var total_len = Math.max.apply(Math, taxes.map(function(tax) { return self.format_currency(tax.total_with_tax).length; }));
                var vat_len = Math.max.apply(Math, taxes.map(function(tax) { return self.format_currency(tax.amount).length; }));

                //var net_text = (t_net + "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0" ).slice(0, Math.max(net_len, t_net.length)+1);
                //var total_text = (t_total + "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0" ).slice(0, Math.max(total_len, t_total.length)+1);
                //var vat_text = (t_vat + "\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0").slice(0, (Math.max(vat_len, t_vat.length)));
                var net_text = (t_net + '\xa0'.repeat(10)).slice(0, Math.max(net_len, t_net.length)+1);
                var vat_text = (t_vat + '\xa0'.repeat(10)).slice(0, (Math.max(vat_len, t_vat.length))+1);
                var total_text = (t_total + '\xa0'.repeat(10)).slice(0, Math.max(total_len, t_total.length));
                right = net_text + vat_text + total_text;
            }

            var t_set = _t("VAT Set");

            var receipt_width = this.pos.get_max_width();
            var tax_header_string = (t_set + '\xa0'.repeat(receipt_width)).slice(0, (Math.max(t_set.length, receipt_width-right.length))) + right;
            return tax_header_string.slice(0, this.pos.get_max_width());
        },
    });

    /**
     *  PaymentScreenWidget does not handle keyCode === 44 (comma)
     */
    screens.PaymentScreenWidget.include({
        init: function (parent, options) {
            var self = this;
            this._super(parent, options);
            this.decimal_point = _t.database.parameters.decimal_point;

            var keyboard_handler = this.keyboard_handler;
            this.keyboard_handler = function (event) {
                if (event.type === "keypress" && event.keyCode === 44) {
                    var key = self.decimal_point;
                    self.payment_input(key);
                    event.preventDefault();
                } else {
                    return keyboard_handler(event);
                }
            };
        },
        payment_input: function (input) {
            // If a single "-" left, this.gui.numpad_input throws exception
            if (this.inputbuffer === '-') {
                this.inputbuffer = '-0';
            }
            this._super(input);
        }
    });

    chrome.Chrome.include({
        build_widgets: function () {
            if (!this.pos.config.order_selector) {
                this.widgets = this.widgets.filter(function (item) {
                    return (item.name !== 'order_selector')
                });
            }
            this._super();
        }
    });

    var PosModelSuper = models.PosModel.prototype;
    models.PosModel = models.PosModel.extend({
        _save_to_server: function (orders, options) {
            var self = this;
            var promise = PosModelSuper._save_to_server.apply(this, arguments);
            promise.done(function (server_ids) {
                if (self.gui.get_current_screen() === 'receipt' || (options.to_invoice && self.gui.get_current_screen() === 'payment')) {
                    var receipt = self.gui.screen_instances['receipt'];
                    receipt.setButtons(server_ids);
                }
            });
            return promise;
        },
        get_proxy: function () {
            return this.proxy;
        },
        // get_separator_line: function(symbol) {
        //     symbol = symbol || "-";
        //     return new Array(parseInt(this.config.bill_width)).join(symbol);
        // },
        get_max_width: function () {
            return this.config.bill_width;
        },

    });

    gui.Gui.include({
        _close: function () {
            var self = this;
            this.chrome.loading_show();
            this.chrome.loading_message(_t('Closing ...'));

            this.pos.push_order().then(function () {
                var url = self.pos.user.pos_restricted ? "/web/session/logout" : "/web#action=point_of_sale.action_client_pos_menu";
                if (session.debug && !self.pos.user.pos_restricted) {
                    url = $.param.querystring(url, {debug: session.debug});
                }
                window.location = url;
            });
        },
    });

});
