/* Copyright 2004-2010 OpenERP SA: License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).
 * Copyright 2017 bridgify GmbH: See LICENSE file for full copyright and licensing details.
 */

odoo.define('bridgify.UserMenu', function (require) {
"use strict";

    var UserMenu = require('web.UserMenu');
    UserMenu.include({
        on_menu_documentation: function () {
            window.open('//bridgify.at/documentation', '_blank');
        },
        on_menu_support: function () {
            window.open('//bridgify.at/support', '_blank');
        },
        on_menu_account: function() {},
    });

});
