/* Copyright 2004-2010 OpenERP SA: License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).
 * Copyright 2017 bridgify GmbH: See LICENSE file for full copyright and licensing details.
 */

odoo.define('bridgify.base', function (require) {
"use strict";

    var core = require('web.core');
    var _t = core._t;

    var WebClient = require('web.WebClient');
    WebClient.include({
        init: function(parent) {
            this._super(parent);
            this.set('title_part', {"zopenerp": 'bridgify'});
        }
    })

});
