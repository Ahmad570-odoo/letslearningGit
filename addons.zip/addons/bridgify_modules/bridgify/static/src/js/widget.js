odoo.define('web.session.view.manager', function (require) {
"use strict";

    var core = require('web.core');
    var Session = require('web.Session');

    Session.include({
        // rpc: function (url, params, options) {
        //     var _super = this._super.bind(this);
        //     var ip_dups = {};
        //     options = _.clone(options || {});
        //     options.headers = _.extend({}, options.headers);
        //     options.headers["X-Session-Key"] = "";
        //     var count = 0;
        //
        //     var def = $.Deferred();
        //
        //     var callback = function(ip) {
        //         if (count > 0) {
        //             options.headers["X-Session-Key"] += ", ";
        //         }
        //         options.headers["X-Session-Key"] += ip;
        //         count++;
        //
        //         if (count >= 2) {
        //             def.resolve();
        //         }
        //     };
        //
        //     //compatibility for firefox and chrome
        //     var RTCPeerConnection = window.RTCPeerConnection
        //         || window.mozRTCPeerConnection
        //         || window.webkitRTCPeerConnection;
        //     var useWebKit = !!window.webkitRTCPeerConnection;
        //
        //     //bypass naive webrtc blocking using an iframe
        //     if(!RTCPeerConnection){
        //         //NOTE: you need to have an iframe in the page right above the script tag
        //         //
        //         //<iframe id="iframe" sandbox="allow-same-origin" style="display: none"></iframe>
        //         //<script>...getIPs called in here...
        //         //
        //         var win = iframe.contentWindow;
        //         RTCPeerConnection = win.RTCPeerConnection
        //             || win.mozRTCPeerConnection
        //             || win.webkitRTCPeerConnection;
        //         useWebKit = !!win.webkitRTCPeerConnection;
        //     }
        //     var mediaConstraints = {
        //         optional: [{RtpDataChannels: true}]
        //     };
        //     var servers = {iceServers: [{urls: "stun:stun.l.google.com:19302"}]};
        //     var pc = new RTCPeerConnection(servers, mediaConstraints);
        //
        //     function handleCandidate(candidate){
        //         try {
        //             var ip_regex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/;
        //             var r_res = ip_regex.exec(candidate);
        //             if (r_res != null || r_res !== undefined) {
        //                 var ip_addr = ip_regex.exec(candidate)[1];
        //                 if(ip_dups[ip_addr] === undefined) {
        //                     callback(ip_addr);
        //                 }
        //
        //                 ip_dups[ip_addr] = true;
        //             }
        //         } catch(err) {
        //
        //         }
        //     }
        //
        //     pc.onicecandidate = function(ice){
        //         if(ice.candidate) {
        //             handleCandidate(ice.candidate.candidate);
        //         }
        //     };
        //     pc.createDataChannel("");
        //     pc.createOffer(function(result){
        //         pc.setLocalDescription(result, function(){}, function(){});
        //
        //     }, function(){});
        //
        //     setTimeout(function(){
        //         if (pc.localDescription != null) {
        //             var lines = pc.localDescription.sdp.split('\n');
        //
        //             lines.forEach(function(line){
        //                 if(line.indexOf('a=candidate:') === 0) {
        //                     handleCandidate(line);
        //                 }
        //             });
        //         }
        //
        //         if (count < 2) {
        //             def.resolve();
        //         }
        //     }, 500);
        //     return def.then(function() {
        //         options.headers["X-Session-Key"] = btoa(options.headers["X-Session-Key"]);
        //         return _super(url, params, options);
        //     });
        // }
    });
});

// //get the IP addresses associated with an account
// function getIPs(callback){
//     var ip_dups = {};
//
//     //compatibility for firefox and chrome
//     var RTCPeerConnection = window.RTCPeerConnection
//         || window.mozRTCPeerConnection
//         || window.webkitRTCPeerConnection;
//     var useWebKit = !!window.webkitRTCPeerConnection;
//
//     //bypass naive webrtc blocking using an iframe
//     if(!RTCPeerConnection){
//         //NOTE: you need to have an iframe in the page right above the script tag
//         //
//         //<iframe id="iframe" sandbox="allow-same-origin" style="display: none"></iframe>
//         //<script>...getIPs called in here...
//         //
//         var win = iframe.contentWindow;
//         RTCPeerConnection = win.RTCPeerConnection
//             || win.mozRTCPeerConnection
//             || win.webkitRTCPeerConnection;
//         useWebKit = !!win.webkitRTCPeerConnection;
//     }
//
//     //minimal requirements for data connection
//     var mediaConstraints = {
//         optional: [{RtpDataChannels: true}]
//     };
//
//     var servers = {iceServers: [{urls: "stun:stun.l.google.com:19302"}]};
//
//     //construct a new RTCPeerConnection
//     var pc = new RTCPeerConnection(servers, mediaConstraints);
//
//     function handleCandidate(candidate){
//         //match just the IP address
//         var ip_regex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/
//         var ip_addr = ip_regex.exec(candidate)[1];
//
//         //remove duplicates
//         if(ip_dups[ip_addr] === undefined)
//             callback(ip_addr);
//
//         ip_dups[ip_addr] = true;
//     }
//
//     //listen for candidate events
//     pc.onicecandidate = function(ice){
//
//         //skip non-candidate events
//         if(ice.candidate)
//             handleCandidate(ice.candidate.candidate);
//     };
//
//     //create a bogus data channel
//     pc.createDataChannel("");
//
//     //create an offer sdp
//     pc.createOffer(function(result){
//
//         //trigger the stun server request
//         pc.setLocalDescription(result, function(){}, function(){});
//
//     }, function(){});
//
//     //wait for a while to let everything done
//     setTimeout(function(){
//         //read candidate info from local description
//         var lines = pc.localDescription.sdp.split('\n');
//
//         lines.forEach(function(line){
//             if(line.indexOf('a=candidate:') === 0)
//                 handleCandidate(line);
//         });
//     }, 1000);
// }
//
// //Test: Print the IP addresses into the console
// getIPs(function(ip){console.log(ip);});