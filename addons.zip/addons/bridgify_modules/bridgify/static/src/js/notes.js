odoo.define('bridgify.notes', function (require) {
    "use strict";

    var core = require('web.core');
    var gui = require('point_of_sale.gui');
    var models = require('point_of_sale.models');
    var screens = require('point_of_sale.screens');

    var QWeb = core.qweb;
    var _t   = core._t;
    // TODO refactor extend to include where needed, require hierarchy, remove copy paste functions (wrap_line, get_separator_line)
    var _super_order = models.Order.prototype;
    models.Order = models.Order.extend({
        set_note: function(note){
            this.note = note;
            this.trigger('change',this);
        },
        get_note: function(){
            return this.note;
        },
        clone: function(){
            var order = _super_order.clone.call(this);
            order.note = this.note;
            return order;
        },
        export_as_JSON: function(){
            var json = _super_order.export_as_JSON.call(this);
            json.note = this.note;
            return json;
        },
        init_from_JSON: function(json){
            _super_order.init_from_JSON.apply(this,arguments);
            this.note = json.note;
        },
        wrap_line: function(line, length, ratio) {
            if (length <= 1) {
                ratio = length;
                length = undefined;
            }
            length = length || this.pos.config.bill_width || 40;
            ratio = ratio || 0.6;
            var MAX_LENGTH = Math.floor(length * ratio);
            var wrapped = [];
            var name = line || '';
            var current_line = "";

            while (name.length > 0) {
                var space_index = name.indexOf(" ");

                if (space_index === -1) {
                    space_index = name.length;
                }

                if (current_line.length + space_index > MAX_LENGTH) {
                    if (current_line.length) {
                        wrapped.push(current_line);
                    }
                    current_line = "";
                }

                current_line += name.slice(0, space_index + 1);
                name = name.slice(space_index + 1);
            }

            if (current_line.length) {
                wrapped.push(current_line);
            }

            return wrapped;
        },
        export_for_printing: function() {
            var self = this;
            var order = _super_order.export_for_printing.call(this);
            return Object.assign(order, {
                note: this.note,
                note_wrapped: self.wrap_line(this.note)
            });
        }
    });

    var _super_orderline = models.Orderline.prototype;
    models.Orderline = models.Orderline.extend({
        initialize: function(attr, options) {
            _super_orderline.initialize.call(this,attr,options);
            this.note = this.note || "";
        },
        set_note: function(note){
            this.note = note;
            this.trigger('change',this);
        },
        get_note: function(){
            return this.note;
        },
        can_be_merged_with: function(orderline) {
            if (orderline.get_note() !== this.get_note()) {
                return false;
            } else {
                return _super_orderline.can_be_merged_with.apply(this,arguments);
            }
        },
        clone: function(){
            var orderline = _super_orderline.clone.call(this);
            orderline.note = this.note;
            return orderline;
        },
        export_as_JSON: function(){
            var json = _super_orderline.export_as_JSON.call(this);
            json.note = this.note;
            return json;
        },
        init_from_JSON: function(json){
            _super_orderline.init_from_JSON.apply(this,arguments);
            this.note = json.note;
        },
        wrap_line: function(line, length, ratio) {
            if (length <= 1) {
                ratio = length;
                length = undefined;
            }
            length = length || this.pos.config.bill_width || 40;
            ratio = ratio || 0.6;
            var MAX_LENGTH = Math.floor(length * ratio);
            var wrapped = [];
            var name = line || '';
            var current_line = "";

            while (name.length > 0) {
                var space_index = name.indexOf(" ");

                if (space_index === -1) {
                    space_index = name.length;
                }

                if (current_line.length + space_index > MAX_LENGTH) {
                    if (current_line.length) {
                        wrapped.push(current_line);
                    }
                    current_line = "";
                }

                current_line += name.slice(0, space_index + 1);
                name = name.slice(space_index + 1);
            }

            if (current_line.length) {
                wrapped.push(current_line);
            }

            return wrapped;
        },
        export_for_printing: function() {
            var self = this;
            var orderline = _super_orderline.export_for_printing.call(this);
            return Object.assign(orderline, {
                note: this.note,
                note_wrapped: self.wrap_line(this.note)
            });
        }
    });

    var OrderlineNoteButton = screens.ActionButtonWidget.extend({
        template: 'OrderlineNoteButton',
        button_click: function(){
            var line = this.pos.get_order().get_selected_orderline();
            if (line) {
                this.gui.show_popup('textarea',{
                    title: _t('Add Note'),
                    value:   line.get_note(),
                    confirm: function(note) {
                        line.set_note(note);
                    },
                });
            }
        },
    });

    screens.define_action_button({
        'name': 'orderline_note',
        'widget': OrderlineNoteButton,
        'condition': function(){
            return this.pos.config.iface_orderline_notes;
        },
    });

    /**
     *  PaymentScreenWidget installs own keyboard handler that does not allow entering notes
     */
    screens.PaymentScreenWidget.include({
        add_keyboard_handler: function() {
            window.document.body.addEventListener('keypress',this.keyboard_handler);
            window.document.body.addEventListener('keydown',this.keyboard_keydown_handler);
        },
        remove_keyboard_handler: function() {
            window.document.body.removeEventListener('keypress',this.keyboard_handler);
            window.document.body.removeEventListener('keydown',this.keyboard_keydown_handler);
        },
        click_note: function(){
            var order = this.pos.get_order();
            if (order) {
                var self = this;
                this.remove_keyboard_handler();
                this.gui.show_popup('textarea',{
                    title: _t('Add Note'),
                    value:   order.get_note(),
                    confirm: function(note) {
                        order.set_note(note);
                        self.add_keyboard_handler();
                    },
                    cancel: function() {
                        self.add_keyboard_handler();
                    }
                });
            }
        },
        renderElement: function() {
            this._super();
            var self = this;
            this.$('.js_note').click(function(){
                self.click_note();
            });
        }
    })
});
