odoo.define('bridgify.pos_discount', function (require) {
"use strict";

    var screens = require('point_of_sale.screens');

    screens.ProductScreenWidget.include({
        start: function() {
            // Trick overloaded class that discount product is defined
            var discount_product_id = this.pos.config.discount_product_id;
            if (!this.pos.config.discount_product_id) {
                this.pos.config.discount_product_id = true;
            }
            this._super();
            this.pos.config.discount_product_id = discount_product_id;
            var discount_button = this.action_buttons['discount'];
            if (discount_button) {
                var super_apply_discount = discount_button.apply_discount;
                Object.assign(discount_button, {
                    apply_discount: function(pc) {
                        if (this.pos.config.discount_product_id) {
                            return super_apply_discount.apply(discount_button, arguments);
                        }
                        var lines = this.pos.get_order().get_orderlines();
                        lines.forEach(function (line){
                            line.set_discount(pc);
                        });
                    }
                });
            }
        }
    });

});
