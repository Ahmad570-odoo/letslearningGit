# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import json
import logging
from odoo import fields, models, api

_logger = logging.getLogger()


class PosOrder(models.Model):
    _inherit = 'pos.order'

    @api.model
    def _order_fields(self, ui_order):
        res = super(PosOrder, self)._order_fields(ui_order)
        res.update({'note': ui_order.get('note', False)})
        return res

    def _action_create_invoice_line(self, line=False, invoice_id=False):
        """ Copy POS order line note
        """
        invoice_line = super(PosOrder, self)._action_create_invoice_line(line=line, invoice_id=invoice_id)
        if line and line.note:
            invoice_line.write({'name': '\n'.join((invoice_line.name, line.note))})
        return invoice_line

    @api.multi
    def _get_tax_amount_by_group(self):
        self.ensure_one()
        taxdetail = {}
        currency = self.pricelist_id.currency_id
        for line in self.lines:
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            tax_ids = line.tax_ids_after_fiscal_position
            for tax in tax_ids.compute_all(price, currency, line.qty, product=line.product_id,
                                           partner=line.order_id.partner_id or False)['taxes']:
                detail = taxdetail.setdefault(tax['id'], {'name': tax['name'], 'base': 0.0, 'amount': 0.0,
                                                          'description': self.env['account.tax'].browse(tax['id']).description})
                detail.update({'base': detail['base'] + tax['base'], 'amount': detail['amount'] + tax['amount']})
        return taxdetail.values()

    @api.multi
    def _serialize(self):
        for order in self:
            order.serialized = json.dumps(order.serialize())

    serialized = fields.Text(compute='_serialize', string='')

    @api.model
    def send_by_email(self, ids, email=None, template_id=None):
        """ Send pos ticket (or the invoice) by email
        """
        template_id = template_id or 'bridgify.email_template_edi_pos_order'
        for order in self.browse(ids):
            partner = order.partner_id
            lang = partner and partner.lang or order.user_id.lang
            res_id = order.id
            template = self.env.ref(template_id, False)
            if order.invoice_id:
                res_id = order.invoice_id.id
                template = self.env.ref('bridgify.email_template_edi_invoice', False)

            if template:
                template.email_to = email or order.invoice_id.partner_id.email
                template.with_context(email=email, partner=partner, lang=lang).send_mail(res_id, force_send=True)
            else:
                _logger.warning("No email template found for sending receipt: %s" % template_id)
        return True

    @api.multi
    def get_access_action(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': '/receipt/html/' + str(self.pos_reference[-14:])
        }

    @api.model
    def get_json(self, ids):
        for order in self.browse(ids):
            return json.dumps(order.serialize())

    @api.multi
    def serialize(self):
        self.ensure_one()
        return {
            'lines': [(0, 0, line.serialize()) for line in self.lines],
            'statement_ids': [(0, 0, line.serialize()) for line in self.statement_ids],
            'sequence_number': self.sequence_number,
            'pos_session_id': self.session_id.id,
            'name' : self.pos_reference,
            'creation_date': self.date_order,
            'uid': self.pos_reference[-14:],
            'partner_id': self.partner_id.id,
            'invoice_id': self.invoice_id.id,
            'cashier': self.user_id and self.user_id.name or '',
            'note': self.note,
            'refund': any([line.qty < 0 for line in self.lines])
        }


class PosOrderLine(models.Model):
    _inherit = "pos.order.line"

    note = fields.Text(string='Internal Notes')

    @api.multi
    def serialize(self):
        self.ensure_one()
        return {
            'id': self.id,
            'product_id': self.product_id.id,
            'qty': self.qty,
            'unit_name': self.product_id.uom_id.name,
            'price_unit': self.price_unit,
            'discount': self.discount,
            'note': self.note,
            'pack_lot_ids': [(0, 0, {
                'lot_name': lot.name
            }) for lot in self.pack_lot_ids]
        }


class ReportSaleDetails(models.AbstractModel):
    _inherit = 'report.point_of_sale.report_saledetails'

    @api.model
    def get_sale_details(self, date_start=False, date_stop=False, configs=False):
        pp = self.env['product.product']
        user_currency = self.env.user.company_id.currency_id
        product_uom_unit = self.env['ir.model.data'].xmlid_to_object('product.product_uom_unit')
        result = super(ReportSaleDetails, self).get_sale_details(date_start=date_start, date_stop=date_stop, configs=configs)
        products = [dict(product, uom=product['uom'] if pp.browse(product['product_id']).uom_id != product_uom_unit else '')
                    for product in result['products']]
        result.update({
            'currency_id': user_currency,
            'products': products
        })
        return result
