# -*- coding: utf-8 -*-

import json
from odoo.tools.misc import formatLang
from odoo import api, fields, models, _


class AccountTax(models.Model):
    _inherit = 'account.tax'

    code = fields.Char('Code', size=1, help='VAT short code can be optionally displayed on POS order line.')

    @api.multi
    def compute_all(self, price_unit, currency=None, quantity=1.0, product=None, partner=None):
        """ Add VAT description to result
        """
        res = super(AccountTax, self).compute_all(price_unit, currency=currency, quantity=quantity, product=product, partner=partner)
        [tax.update({'description': self.browse(tax['id']).description}) for tax in res.get('taxes', [])]
        return res


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'

    @api.multi
    def _pos_reference(self):
        for invoice in self:
            if invoice.pos_order_id:
                invoice.pos_reference = invoice.pos_order_id.pos_reference[-14:]

    pos_order_id = fields.One2many('pos.order', 'invoice_id', string='POS Order', copy=False)
    pos_reference = fields.Char(string='POS Reference', compute='_pos_reference')

    def get_payment_info(self):
        info = json.loads(self.payments_widget)
        payment_info = info['content'] if 'content' in info else []
        [payment.update({'amount_str': formatLang(self.env, payment['amount'], currency_obj=self.company_id.currency_id)})
         for payment in payment_info]
        return payment_info


class AccountBankStatementLine(models.Model):
    _inherit = "account.bank.statement.line"

    @api.multi
    def serialize(self):
        self.ensure_one()
        return {
            'amount': self.amount,
            'name': self.journal_id.name_get()[0][1],
            'journal_id': self.journal_id.name_get()[0],
            'account_id': self.statement_id.account_id.name_get()[0],
            'statement_id': self.statement_id.id
        }
