# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class PosConfig(models.Model):
    _inherit = 'pos.config'

    bill_width = fields.Selection([('40', 'Wide (80mm)'), ('32', 'Narrow (58mm)')], string='Receipt width',
                                  required=True, default='40')

    order_selector = fields.Boolean(string='Order Selector', default=True,
                                    help="Allows the cashier to create / delete and switch between orders.")
    iface_orderline_notes = fields.Boolean(string='Notes', help='Allow custom notes (order lines & payment)')
