# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _


class ResCompany(models.Model):
    _inherit = "res.company"

    def _display_address(self):
        for company in self:
            partner = company.partner_id
            args = {
                'state_code': partner.state_id.code or '',
                'state_name': partner.state_id.name or '',
                'country_code': partner.country_id.code or '',
                'country_name': partner.country_id.name or '',
                'company_name': partner.commercial_company_name or '',
            }
            for field in partner._address_fields():
                args[field] = getattr(partner, field) or ''
            company.display_address = company.address_format % args

    def _get_sale_taxes(self):
        ir_values = self.env['ir.values']
        for company in self:
            tax = ir_values.get_default('product.template', 'taxes_id', for_all_users=True, company_id=company.id)
            company.default_sale_tax_id = tax[0] if tax else False

    def _set_sale_taxes(self):
        for company in self:
            tax_id = company.default_sale_tax_id.id
            self.env['ir.values'].sudo().set_default('product.template', 'taxes_id',
                [tax_id] if tax_id else False, for_all_users=True, company_id=company.id)

    def _set_purchase_taxes(self):
        for company in self:
            tax_id = company.default_purchase_tax_id.id
            self.env['ir.values'].sudo().set_default('product.template', 'supplier_taxes_id',
                 [tax_id] if tax_id else False, for_all_users=True, company_id=company.id)

    def _get_purchase_taxes(self):
        ir_values = self.env['ir.values']
        for company in self:
            tax = ir_values.get_default('product.template', 'supplier_taxes_id', for_all_users=True, company_id=company.id)
            company.default_purchase_tax_id = tax[0] if tax else False

    tax_number = fields.Char('Tax number')

    tax_ids = fields.One2many('account.tax', 'company_id', string='Taxes')
    default_sale_tax_id = fields.Many2one('account.tax', string="Default Sale Tax",
                                          compute='_get_sale_taxes', inverse='_set_sale_taxes',
                                          help="This sale tax will be assigned by default on new products.")
    sale_tax_include = fields.Boolean(string='Included in Price', default=True,
                                      help="Check this if the product sales price includes output taxes.")

    default_purchase_tax_id = fields.Many2one('account.tax', string="Default Purchase Tax",
                                              compute='_get_purchase_taxes', inverse='_set_purchase_taxes',
                                              help="This purchase tax will be assigned by default on new products.")
    purchase_tax_include = fields.Boolean(string='Included in Price', default=False,
                                          help="Check this if the product purchase price includes input taxes.")

    display_address = fields.Char(compute='_display_address', string='Complete Address')
    address_format = fields.Text(help="""Company address format on PoS receipt. \
    \n\nYou can use the python-style string pattern with all the field of the address \
    (for example, use '%(street)s' to display the field 'street') plus
                \n%(country_name)s: the name of the country
                \n%(country_code)s: the code of the country""",
                                 default='%(street)s<br />%(zip)s %(city)s')

    display_logo = fields.Boolean('Display logo', help='Display company logo on PoS receipt?', default=False)
    display_email = fields.Boolean('Display email', help='Display email address on PoS receipt?', default=True)
    display_website = fields.Boolean('Display website', help='Display web site address on PoS receipt?', default=True)
    display_phone = fields.Boolean('Display phone', help='Display phone number on PoS receipt?', default=True)
    display_tax_code = fields.Boolean('Display VAT code', help='Display VAT short code on PoS receipt line?', default=False)

    receipt_address_location = fields.Selection([('below-image', _('Below Image')), ('bottom', 'Bottom')],
                                                string=_("Receipt Address Location"),
                                                required=True, default='below-image')
    big_header_text = fields.Boolean('Double size header text?', help='Display header text with double size?',
                                      default=False)

    @api.onchange('sale_tax_include')
    def onchange_sale_tax_include(self):
        return self.change_tax_include('sale', self.sale_tax_include)

    @api.onchange('purchase_tax_include')
    def onchange_purchase_tax_include(self):
        return self.change_tax_include('purchase', self.purchase_tax_include)

    def change_tax_include(self, tax_use, flag):
        for tax in self.tax_ids.filtered(lambda r: r.type_tax_use == tax_use):
            tax.price_include = flag
            tax.include_base_amount = flag
