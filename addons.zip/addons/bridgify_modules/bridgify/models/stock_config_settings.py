# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class StockSettings(models.TransientModel):
    _inherit = 'stock.config.settings'

    module_pos_variants = fields.Boolean("POS Variants")

    @api.multi
    def set_pos_product_action(self):
        """ Change model to product.template if product variants are enabled
        """
        for config in self:
            self.module_pos_variants = config.group_product_variant == 1
            product_product_action = self.env['ir.model.data'].xmlid_to_object('point_of_sale.product_product_action')
            product_product_action.res_model = config.group_product_variant and 'product.template' or 'product.product'
        return True
