# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import logging

from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class PosSession(models.Model):
    _inherit = 'pos.session'

    def _report_filter_hook(self):
        """ Hook for pos_digital_signature to exclude RKSV technical receipts
        """
        try:
            return super(PosSession, self)._report_filter_hook()
        except AttributeError:
            return ''

    @api.multi
    def compute_taxes(self, line_filter=''):
        taxes = {}
        self.ensure_one()
        currency = self.currency_id
        total_excluded = total_included = 0.0
        pos_orders = self.order_ids
        pos_orders = pos_orders.filtered(self._report_filter_hook())
        for line in pos_orders.mapped('lines').filtered(line_filter):
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            tax_ids = line.tax_ids_after_fiscal_position
            tax_detail = tax_ids.compute_all(price, currency, line.qty, product=line.product_id,
                                             partner=line.order_id.partner_id or False)
            total_excluded += tax_detail['total_excluded']
            total_included += tax_detail['total_included']
            for tax in tax_detail['taxes']:
                detail = taxes.setdefault(tax['id'], {'name': tax['name'], 'sequence': tax['sequence'],
                                                      'tags': ', '.join(set(self.env['account.tax'].browse(tax['id']).mapped('tag_ids').mapped('name'))),
                                                      'base': 0.0, 'amount': 0.0})
                detail.update({'base': detail['base'] + tax['base'], 'amount': detail['amount'] + tax['amount']})
            if len(tax_detail['taxes']) == 0:
                detail = taxes.setdefault(0, {'name': _('(no tax)'), 'sequence': 100, 'tags': _('(no tax defined)'), 'base': 0.0, 'amount': 0.0})
                detail.update({'base': detail['base'] + tax_detail['total_excluded']})

        return {
            'total_excluded': total_excluded,
            'total_included': total_included,
            'taxes': sorted(taxes.values(), key=lambda r: r.get('sequence'))
        }

    @api.multi
    def compute_products(self):
        self.ensure_one()
        pos_orders = self.order_ids.filtered(self._report_filter_hook())
        pos_order_lines = pos_orders.mapped('lines')
        products = [{'name': product.name, 'price_unit': [line.price_unit for line in pos_order_lines.filtered(lambda l: l.product_id == product)][0],
                     'variant_name': ', '.join(product.attribute_value_ids.mapped('name')),
                     'qty': sum([line.qty for line in pos_order_lines.filtered(lambda l: l.product_id == product)]),
                     'subtotal': sum([line.price_subtotal
                                      for line in pos_order_lines.filtered(lambda l: l.product_id == product)]),
                     'taxes': ', '.join(set([tax.description for tax in pos_order_lines
                                            .filtered(lambda l: l.product_id == product)
                                            .mapped('tax_ids_after_fiscal_position')])),
                     'subtotal_incl': sum([line.price_subtotal_incl
                                           for line in pos_order_lines.filtered(lambda l: l.product_id == product)]),
                     'uom': product.uom_id.name if product.uom_id.id != 1 else ''}
                    for product in pos_order_lines.mapped('product_id').sorted('name')]
        return {
            'total_excluded': sum([p['subtotal'] for p in products]),
            'total_included': sum([p['subtotal_incl'] for p in products]),
            'products': products
        }

    # FIX: https://github.com/odoo/odoo/pull/24486
    @api.multi
    def login(self):
        self.ensure_one()
        login_number = self.login_number + 1
        self.write({
            'login_number': login_number,
        })
        return login_number