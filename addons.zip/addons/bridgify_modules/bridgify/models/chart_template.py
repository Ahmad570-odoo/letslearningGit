# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class WizardMultiChartsAccounts(models.TransientModel):
    _inherit = 'wizard.multi.charts.accounts'

    @api.multi
    def _create_bank_journals_from_o2m(self, company, acc_template_ref):
        '''
        This function is currently only used to create a default bank and cash journal when the CoA is installed
        What we need is to make those available in POS as payment methods
        '''
        self.ensure_one()
        for acc in self.bank_account_ids:
            self.env['account.journal'].create({
                'name': _(acc.acc_name),
                'type': acc.account_type,
                'company_id': company.id,
                'currency_id': acc.currency_id.id,
                'sequence': 10 if acc.account_type == 'cash' else 20,
                'journal_user': True
            })
