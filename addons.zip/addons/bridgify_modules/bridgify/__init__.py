# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import os
import json
import models
import reports
import controllers

with open(os.path.dirname(os.path.abspath(__file__)) + '/config.json') as data_file:
    config = json.load(data_file)
