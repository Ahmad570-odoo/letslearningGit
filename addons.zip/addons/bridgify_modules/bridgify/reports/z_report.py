# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import api, models


class ZReport(models.AbstractModel):
    _name = 'report.bridgify.z_report'

    @api.model
    def render_html(self, docids, data=None):
        return self.env['report'].render('bridgify.report_session', {
            'doc_ids': docids,
            'doc_model': 'pos.session',
            'docs': self.env['pos.session'].browse(docids),
            'z_report': True
        })
