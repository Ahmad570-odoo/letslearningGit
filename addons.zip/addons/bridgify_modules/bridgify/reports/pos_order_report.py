# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, tools


class PosOrderReport(models.Model):
    _inherit = "report.pos.order"

    gross_profit = fields.Float(string='Gross Profit', readonly=True)

    def _report_add_where_hook(self):
        return '1=1'

    @api.model_cr
    def init(self):
        self._cr.execute("DROP FUNCTION IF EXISTS compute_net_amount(CHAR, INT, NUMERIC, NUMERIC, NUMERIC) CASCADE")
        self._cr.execute("""
            CREATE OR REPLACE FUNCTION compute_net_amount(
              tax_type char, product_id int, quantity NUMERIC, price NUMERIC default Null, discount NUMERIC default 0
            ) RETURNS NUMERIC AS $$
             DECLARE
                query text;
                rec record;
                amount NUMERIC := 0;
             BEGIN
                query := 'SELECT amount_type, amount FROM account_tax t JOIN ';
                if tax_type = 'sale' then
                  query := query || 'product_taxes_rel r';
                elsif tax_type = 'purchase' then
                  query := query || 'product_supplier_taxes_rel r';
                  if price IS NULL then
                    SELECT value_float INTO price
                      FROM ir_property i JOIN product_template pt ON pt.company_id=i.company_id
                        JOIN product_product p ON p.product_tmpl_id=pt.id AND i.res_id='product.product,'||p.id
                      WHERE i.name='standard_price' and p.id=product_id;
                    if not found then 
                      price := 0;
                    end if;
                  end if;  
                else         
                  raise exception 'Invalid tax type %s. Valid values are "sale", "purchase"', tax_type;
                end if;
                query := query || ' ON t.id=r.tax_id ' ||
                 'JOIN product_template pt ON r.prod_id=pt.id ' ||
                  'JOIN product_product p ON pt.id=p.product_tmpl_id ' ||
                 'WHERE t.price_include is TRUE AND p.id=$1';
                amount := (quantity * price) * (100 - discount) / 100;
                for rec in execute query using product_id loop
                    if rec.amount_type = 'fixed' then
                        amount := sign(amount) * abs(quantity) * rec.amount;
                    end if;
                    if rec.amount_type = 'percent' then
                        amount := sign(amount) * (abs(amount) / (1 + rec.amount / 100));
                    end if;
                end loop;
                
                return amount;
             END;
            $$ LANGUAGE plpgsql;
    """)
        tools.drop_view_if_exists(self._cr, 'report_pos_order')
        self._cr.execute("""
            CREATE OR REPLACE VIEW report_pos_order AS (
                SELECT
                    MIN(l.id) AS id,
                    COUNT(*) AS nbr_lines,
                    s.date_order AS date,
                    SUM(l.qty) AS product_qty,
                    SUM(l.qty * l.price_unit) AS price_sub_total,
                    SUM((l.qty * l.price_unit) * (100 - l.discount) / 100) AS price_total,
                    SUM(compute_net_amount('sale', p.id, l.qty, l.price_unit, l.discount) - compute_net_amount('purchase', p.id, l.qty)) AS gross_profit,
                    SUM((l.qty * l.price_unit) * (l.discount / 100)) AS total_discount,
                    (SUM(l.qty*l.price_unit)/SUM(l.qty * u.factor))::decimal AS average_price,
                    SUM(cast(to_char(date_trunc('day',s.date_order) - date_trunc('day',s.create_date),'DD') AS INT)) AS delay_validation,
                    s.id as order_id,
                    s.partner_id AS partner_id,
                    s.state AS state,
                    s.user_id AS user_id,
                    s.location_id AS location_id,
                    s.company_id AS company_id,
                    s.sale_journal AS journal_id,
                    l.product_id AS product_id,
                    pt.categ_id AS product_categ_id,
                    p.product_tmpl_id,
                    ps.config_id,
                    pt.pos_categ_id,
                    pc.stock_location_id,
                    s.pricelist_id,
                    s.session_id,
                    s.invoice_id IS NOT NULL AS invoiced
                FROM pos_order_line AS l
                    LEFT JOIN pos_order s ON (s.id=l.order_id)
                    LEFT JOIN product_product p ON (l.product_id=p.id)
                    LEFT JOIN product_template pt ON (p.product_tmpl_id=pt.id)
                    LEFT JOIN product_uom u ON (u.id=pt.uom_id)
                    LEFT JOIN pos_session ps ON (s.session_id=ps.id)
                    LEFT JOIN pos_config pc ON (ps.config_id=pc.id)
                WHERE %s
                GROUP BY
                    s.id, s.date_order, s.partner_id,s.state, pt.categ_id,
                    s.user_id, s.location_id, s.company_id, s.sale_journal,
                    s.pricelist_id, s.invoice_id, s.create_date, s.session_id,
                    l.product_id,
                    pt.categ_id, pt.pos_categ_id,
                    p.product_tmpl_id,
                    ps.config_id,
                    pc.stock_location_id
                HAVING
                    SUM(l.qty * u.factor) != 0
            )
        """ % self._report_add_where_hook())
